# Cómo está hecho

## Piezas

1. **Motor de reglas** (`shared/engine.js`): reparto, jugadas válidas, pase, pase corrido, capicúa, tranque, puntos y
   modos. No dibuja nada: recibe acciones y devuelve eventos (`round`, `pick`, `pozo`, `start`, `turn`, `play`, `draw`,
   `pass`, `corrido`, `roundEnd`).
2. **Mesa** (`shared/room.js`): lleva una partida sobre el motor con tiempos de turno, jugadores de la computadora,
   desconexiones y el ritmo de las animaciones. La usa el servidor (en línea) y el navegador (práctica).
3. **Servidor** (`server/`):
   - `index.js` sirve los archivos públicos, la API y el WebSocket `/ws`.
   - `hub.js` conexiones, presencia, chat, búsqueda de mesa, mesas, cobro de apuestas y premios.
   - `api.js` cuentas, bonos, ranking, soporte y administración. `users.js` cuentas y sesiones. `db.js` SQLite.
   - `moderation.js` filtro del chat y límites. `ws.js` WebSocket sin dependencias. `config.js` variables.
4. **Cliente** (`index.html`): el lobby (`js/lobby/`) y la mesa (`js/core`, `js/game`, `js/render`). La mesa recibe
   eventos en `js/game/driver.js` y los muestra en orden, esperando cada animación.

## Seguridad

- El servidor decide todo: el navegador solo ve sus fichas (las de los demás nunca se envían) y solo puede pedir jugadas
  válidas. Las monedas se mueven en la base de datos con historial (`ledger`).
- Contraseñas con scrypt; sesiones con token aleatorio guardado como hash.
- Límite de peticiones para crear cuentas, entrar, chatear, reportar y escribir a soporte.
- Si el servidor se reinicia con partidas a medias, devuelve las apuestas.

## Ajustes rápidos

| Qué | Dónde |
|---|---|
| Montos de las mesas | `STAKES` en `server/config.js` |
| Metas (200 parejas / 100 1 vs 1) y puntos de pase | `MODES`, `PASE_PTS`, `CORRIDO_PTS` en `shared/engine.js` |
| Tiempos (turno, pase automático, espera de la computadora) | `T` en `shared/room.js` |
| Palabras bloqueadas en el chat | `BAD` en `server/moderation.js` |
| Preguntas frecuentes | `FAQ` en `js/lobby/lobby.js` |
| Temas de paño, madera y fichas | `js/render/theme.js` y `shared/profile.js` |
