# Poner el juego en línea

El juego ahora tiene **servidor**: guarda cuentas y monedas, arma las mesas, lleva el chat y el soporte. Por eso ya no
basta con Vercel (que solo sirve páginas): necesitas un hosting que mantenga un programa de Node.js encendido y un
**disco persistente** para la base de datos.

**Recomendado: Railway** (lo más sencillo, ~US$5 al mes). También sirven Fly.io, Render (plan con disco) o cualquier VPS con Docker.

## Railway paso a paso

1. Sube el proyecto a GitHub (ver más abajo).
2. En [railway.com](https://railway.com) → **New Project → Deploy from GitHub repo** → elige `domino-dominicano`.
   Railway detecta el `Dockerfile` y lo construye solo.
3. En el servicio → **Settings → Volumes → Add volume**, móntalo en **`/data`** (ahí vive la base de datos; sin volumen, las cuentas y monedas se borran en cada despliegue).
4. En **Variables** agrega:
   | Variable | Valor |
   |---|---|
   | `ADMIN_KEY` | una clave larga y secreta (para el panel de soporte en `/admin`) |
   | `DATA_DIR` | `/data` |
5. **Settings → Networking → Generate Domain** (o conecta tu dominio propio). Abre la dirección: ya está el juego.
6. Corre `npm run domain -- https://tu-direccion` y vuelve a subir, para que Google y la vista previa de WhatsApp usen tu dirección.

Cada cambio que subas a GitHub se publica solo.

## Subir a GitHub

```bash
git add .
git commit -m "Dominó Dominicano 2.0.0"
git remote add origin https://github.com/TU-USUARIO/domino-dominicano.git
git push -u origin main
```

## Variables que puedes ajustar

| Variable | Por defecto | Qué hace |
|---|---|---|
| `ADMIN_KEY` | (vacía) | Clave del panel `/admin`. Sin ella el panel está apagado. |
| `DATA_DIR` | `./data` | Carpeta de la base de datos (usa un volumen). |
| `START_COINS` | 500 | Monedas de bienvenida. |
| `DAILY_COINS` | 100 | Bono diario. |
| `RESCUE_COINS` / `RESCUE_EVERY_H` | 50 / 6 | Bono si te quedas sin monedas. |
| `QUEUE_WAIT_MS` | 12000 | Tiempo que se espera a otras personas antes de completar la mesa con la computadora. |
| `ALLOWED_ORIGINS` | (vacía) | Si pones el sitio en un dominio distinto al del servidor. |

Los montos de las mesas (10, 20, 40, 80) están en `server/config.js` (`STAKES`).

## Panel de soporte

Entra a `https://tu-direccion/admin` con tu `ADMIN_KEY`. Desde ahí:
- respondes las consultas de los jugadores (les llega aviso en el juego),
- revisas los reportes del chat, borras mensajes y silencias o suspendes cuentas,
- ajustas monedas a un jugador (por ejemplo, para compensar un error).

## Copias de seguridad

Toda la información está en un solo archivo: `DATA_DIR/domino.db`. Haz copias de ese archivo de vez en cuando
(en Railway: volumen → Backups).

## Probar en tu computadora

Necesitas Node.js 22.13 o más nuevo.

```bash
npm start                 # http://localhost:3000
ADMIN_KEY=prueba npm start   # con panel de soporte
npm test                  # reglas (3.000 partidas simuladas) + servidor con varios jugadores
```
