/* Dominó Dominicano · motor de reglas (compartido)
 * Lo usa el servidor (partidas en línea) y el navegador (modo práctica). No dibuja nada ni sabe de pantallas:
 * recibe acciones (tomar ficha, jugar, pasar) y devuelve eventos que describen lo que pasó.
 *
 * Modos:
 *   parejas  4 jugadores, dos equipos (0 y 2 contra 1 y 3). Se reparten las 28 fichas, 7 a cada uno.
 *   duelo    1 vs 1. Cada uno toma 7; las 14 que sobran quedan boca abajo en el pozo. Si no llevas, robas del pozo
 *            hasta que te salga una que sirva; si el pozo está vacío, pasas.
 *
 * Reglas dominicanas: en la primera mano sale el doble seis (en duelo, el doble más alto que haya en las manos).
 * Pase normal: +25 para el equipo de quien jugó. Pase corrido (parejas: nadie más lleva después de una jugada): +30 y
 * vuelve a jugar quien jugó. Capicúa: ganar con una ficha que entra por las dos puntas, siendo las puntas distintas.
 * Tranque: nadie puede jugar; gana el equipo (o jugador) con menos puntos en la mano.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.DomEngine = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  // ---- fichas ----
  const TILES = [];
  for (let a = 0; a <= 6; a++) for (let b = a; b <= 6; b++) TILES.push([a, b]);
  const tileOf = (id) => TILES[id];
  const idOf = (a, b) => TILES.findIndex((t) => (t[0] === a && t[1] === b) || (t[0] === b && t[1] === a));
  const pips = (id) => TILES[id][0] + TILES[id][1];
  const isDouble = (id) => TILES[id][0] === TILES[id][1];

  const MODES = {
    parejas: { key: 'parejas', label: 'Parejas', n: 4, teams: true, deal: 7, draw: false, target: 200 },
    duelo: { key: 'duelo', label: '1 vs 1', n: 2, teams: false, deal: 7, draw: true, target: 100 }
  };
  const PASE_PTS = 25, CORRIDO_PTS = 30;

  // ---- azar con semilla (el servidor usa semillas criptográficas) ----
  function rngFrom(seed) {
    let a = seed >>> 0;
    return function () { a |= 0; a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  }
  const shuffle = (arr, rnd) => { for (let i = arr.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); const x = arr[i]; arr[i] = arr[j]; arr[j] = x; } return arr; };

  // ---- dónde quedan las fichas boca abajo para tomarlas (sin encimarse); medidas de la mesa del juego ----
  const BW = 960, BH = 480, TL = 72, TW = 36;
  function obbHit(a, b, m) {
    const ax = [[Math.cos(a.a), Math.sin(a.a)], [-Math.sin(a.a), Math.cos(a.a)], [Math.cos(b.a), Math.sin(b.a)], [-Math.sin(b.a), Math.cos(b.a)]];
    const dx = b.x - a.x, dy = b.y - a.y;
    for (const [nx, ny] of ax) {
      const r = (q) => (TL / 2 + m) * Math.abs(Math.cos(q.a) * nx + Math.sin(q.a) * ny) + (TW / 2 + m) * Math.abs(-Math.sin(q.a) * nx + Math.cos(q.a) * ny);
      if (Math.abs(dx * nx + dy * ny) > r(a) + r(b)) return false;
    }
    return true;
  }
  function deckLayout(rnd) {
    const pts = [], R = (a, b) => a + rnd() * (b - a);
    for (let i = 0; i < 28; i++) {
      let q = null;
      for (const m of [14, 8, 3, 0]) {
        for (let tr = 0; tr < 900 && !q; tr++) { const c = { x: R(-BW / 2 + 56, BW / 2 - 56), y: R(56, BH - 72), a: R(0, 6.28) }; if (pts.every((p) => !obbHit(p, c, m))) q = c; }
        if (q) break;
      }
      if (!q) q = { x: R(-BW / 2 + 56, BW / 2 - 56), y: R(56, BH - 72), a: R(0, 6.28) };
      pts.push({ x: Math.round(q.x * 10) / 10, y: Math.round(q.y * 10) / 10, a: Math.round(q.a * 1000) / 1000 });
    }
    return pts;
  }

  // ---- partida ----
  function newMatch(mode, opts) {
    const cfg = Object.assign({}, MODES[mode] || MODES.parejas, (opts && opts.cfg) || {});
    const seed = (opts && opts.seed != null) ? opts.seed : Math.floor(Math.random() * 4294967296);
    return {
      mode: cfg.key, cfg, n: cfg.n, rnd: rngFrom(seed), scores: [0, 0], round: 0, phase: 'idle',
      nextStarter: null, lastStarter: -1, hands: [], deck: [], pos: [], pozo: [], chain: [], ends: null,
      turn: -1, passRun: 0, lastPlayer: -1, mustPlay: null, result: null, winnerTeam: null
    };
  }
  const teamOf = (st, p) => (st.cfg.teams ? p % 2 : p);

  function startRound(st) {
    if (st.phase === 'over') throw new Error('La partida terminó');
    st.round++;
    const ids = shuffle(TILES.map((_, i) => i), st.rnd);
    st.pos = deckLayout(st.rnd);
    st.deck = ids.map((id) => ({ id, owner: -1 }));
    st.hands = Array.from({ length: st.n }, () => []);
    st.pozo = []; st.chain = []; st.ends = null; st.turn = -1; st.passRun = 0; st.lastPlayer = -1; st.mustPlay = null; st.result = null;
    st.phase = 'pick';
    return [{ type: 'round', round: st.round, mode: st.mode, n: st.n, scores: st.scores.slice(), target: st.cfg.target, pos: st.pos }];
  }

  const freeDeck = (st) => st.deck.map((d, i) => (d.owner < 0 ? i : -1)).filter((i) => i >= 0);
  const pickDone = (st) => st.hands.every((h) => h.length >= st.cfg.deal);

  // p toma la ficha i de la mesa (boca abajo)
  function pick(st, p, i) {
    if (st.phase !== 'pick') throw new Error('No es momento de tomar fichas');
    if (st.hands[p].length >= st.cfg.deal) throw new Error('Ya tienes tus fichas');
    const d = st.deck[i];
    if (!d || d.owner >= 0) throw new Error('Esa ficha ya la tomaron');
    d.owner = p; st.hands[p].push(d.id);
    const ev = [{ type: 'pick', p, i, tile: d.id, priv: p }];
    if (pickDone(st)) ev.push(...finishDeal(st));
    return ev;
  }

  function finishDeal(st) {
    const ev = [];
    if (st.cfg.draw) {
      st.pozo = freeDeck(st).map((i) => { st.deck[i].owner = 99; return st.deck[i].id; });
      ev.push({ type: 'pozo', idx: st.deck.map((d, i) => (d.owner === 99 ? i : -1)).filter((i) => i >= 0) });
    }
    // quién sale
    let starter = st.nextStarter, must = null;
    if (st.round === 1 || starter == null) {
      if (st.cfg.teams) { must = 27; starter = st.hands.findIndex((h) => h.includes(27)); } // 6|6
      else {
        // el doble más alto que haya en las manos (si nadie tiene doble, la ficha más alta)
        let best = -1, bestScore = -1;
        st.hands.forEach((h, p) => h.forEach((id) => { const s = (isDouble(id) ? 100 : 0) + pips(id) * 2 + TILES[id][1] / 10; if (s > bestScore) { bestScore = s; best = p; must = id; } }));
        starter = best;
      }
    }
    st.mustPlay = must; st.lastStarter = starter; st.turn = starter; st.phase = 'play'; st.passRun = 0;
    ev.push({ type: 'start', starter, must, pozo: st.pozo.length });
    ev.push(turnEv(st));
    return ev;
  }

  // ---- jugadas posibles ----
  function legal(st, p) {
    if (st.phase !== 'play') return [];
    const h = st.hands[p], out = [];
    if (!st.chain.length) {
      for (const id of h) if (st.mustPlay == null || id === st.mustPlay) out.push({ id, end: 'C' });
      return out;
    }
    for (const id of h) {
      const [a, b] = TILES[id];
      if (a === st.ends.L || b === st.ends.L) out.push({ id, end: 'L' });
      if (a === st.ends.R || b === st.ends.R) out.push({ id, end: 'R' });
    }
    return out;
  }
  const canPlay = (st, p) => legal(st, p).length > 0;

  function turnEv(st) { return { type: 'turn', p: st.turn, legalFor: st.turn }; }

  function play(st, p, id, end) {
    if (st.phase !== 'play') throw new Error('No es momento de jugar');
    if (st.turn !== p) throw new Error('No es tu turno');
    const mv = legal(st, p).find((m) => m.id === id && (m.end === end || (end == null)));
    if (!mv) throw new Error('Esa ficha no entra ahí');
    end = mv.end;
    const [a, b] = TILES[id];
    const hand = st.hands[p];
    // capicúa: última ficha, entra por las dos puntas y las puntas son distintas
    let cap = false, nums = null;
    if (st.chain.length && hand.length === 1) {
      nums = [st.ends.L, st.ends.R];
      cap = nums[0] !== nums[1] && ((a === nums[0] && b === nums[1]) || (a === nums[1] && b === nums[0]));
    }
    hand.splice(hand.indexOf(id), 1);
    if (end === 'C') st.ends = { L: a, R: b };
    else { const open = st.ends[end]; st.ends[end] = a === open ? b : a; }
    st.chain.push({ p, id, end });
    st.passRun = 0; st.lastPlayer = p; st.mustPlay = null;
    const ev = [{ type: 'play', p, tile: id, end }];
    if (!hand.length) { ev.push(...endRound(st, 'domino', p, cap, nums)); return ev; }
    if (st.cfg.teams) {
      const others = [1, 2, 3].map((d) => (p + d) % st.n);
      if (others.every((o) => !canPlay(st, o))) {
        if (canPlay(st, p)) { // PASE CORRIDO
          st.scores[teamOf(st, p)] += CORRIDO_PTS;
          ev.push({ type: 'corrido', p, pts: CORRIDO_PTS, team: teamOf(st, p), scores: st.scores.slice() });
          st.turn = p; st.passRun = 0; ev.push(turnEv(st));
        } else { // tranque: nadie lleva, ni quien jugó
          ev.push({ type: 'corrido', p, tranque: true });
          ev.push(...endRound(st, 'block'));
        }
        return ev;
      }
    }
    ev.push(...advance(st));
    return ev;
  }

  // siguiente turno (en duelo, quien no lleva roba del pozo hasta que le salga una)
  function advance(st) {
    const ev = [];
    st.turn = (st.turn + 1) % st.n;
    if (st.cfg.draw) {
      while (!canPlay(st, st.turn) && st.pozo.length) {
        const id = st.pozo.pop(), i = st.deck.findIndex((d) => d.id === id);
        st.deck[i].owner = st.turn; st.hands[st.turn].push(id);
        ev.push({ type: 'draw', p: st.turn, i, tile: id, priv: st.turn, left: st.pozo.length });
      }
    }
    ev.push(turnEv(st));
    return ev;
  }

  function pass(st, p) {
    if (st.phase !== 'play') throw new Error('No es momento de pasar');
    if (st.turn !== p) throw new Error('No es tu turno');
    if (canPlay(st, p)) throw new Error('Tienes ficha para jugar');
    let bonus = null;
    if (st.passRun === 0 && st.lastPlayer >= 0 && teamOf(st, st.lastPlayer) !== teamOf(st, p)) {
      const team = teamOf(st, st.lastPlayer);
      st.scores[team] += PASE_PTS; bonus = { team, pts: PASE_PTS, giver: st.lastPlayer };
    }
    st.passRun++;
    const ev = [{ type: 'pass', p, bonus, scores: st.scores.slice() }];
    if (st.passRun >= st.n) { ev.push(...endRound(st, 'block')); return ev; }
    ev.push(...advance(st));
    return ev;
  }

  function endRound(st, kind, winner, cap, nums) {
    const sums = st.hands.map((h) => h.reduce((s, id) => s + pips(id), 0));
    const total = sums.reduce((a, b) => a + b, 0);
    let team = -1, pts = 0, by = winner == null ? -1 : winner;
    if (kind === 'domino') {
      team = teamOf(st, winner);
      pts = st.cfg.teams ? total : total - sums[winner];
      st.nextStarter = winner;
    } else {
      if (st.cfg.teams) {
        const t0 = sums[0] + sums[2], t1 = sums[1] + sums[3];
        team = t0 < t1 ? 0 : t1 < t0 ? 1 : -1;
        if (team >= 0) { const m = team === 0 ? [0, 2] : [1, 3]; by = sums[m[0]] <= sums[m[1]] ? m[0] : m[1]; pts = total; }
      } else {
        team = sums[0] < sums[1] ? 0 : sums[1] < sums[0] ? 1 : -1;
        if (team >= 0) { by = team; pts = sums[1 - team]; }
      }
      st.nextStarter = team >= 0 ? by : (st.lastStarter + 1) % st.n;
    }
    if (team >= 0) st.scores[team] += pts;
    const target = st.cfg.target;
    let over = st.scores[0] >= target || st.scores[1] >= target;
    let winnerTeam = null;
    if (over) winnerTeam = st.scores[0] === st.scores[1] ? (team >= 0 ? team : 0) : (st.scores[0] > st.scores[1] ? 0 : 1);
    st.phase = over ? 'over' : 'roundEnd'; st.turn = -1; st.winnerTeam = winnerTeam;
    st.result = { kind, winner: by, team, cap: !!cap, nums: nums || null, pts, sums, hands: st.hands.map((h) => h.slice()), scores: st.scores.slice(), over, winnerTeam };
    return [Object.assign({ type: 'roundEnd' }, st.result)];
  }

  // ---- jugador de la computadora: solo mira su mano y la mesa (no hace trampa) ----
  function botMove(st, p, rnd) {
    const ms = legal(st, p);
    if (!ms.length) return null;
    const r = rnd || Math.random, hand = st.hands[p];
    let best = null, bs = -1e9;
    for (const m of ms) {
      const [a, b] = TILES[m.id];
      const open = m.end === 'C' ? b : (a === st.ends[m.end] ? b : a);
      const other = m.end === 'C' ? a : st.ends[m.end === 'L' ? 'R' : 'L'];
      const rest = hand.filter((x) => x !== m.id);
      const keep = rest.filter((x) => TILES[x].includes(open) || TILES[x].includes(other)).length;
      const sc = a + b + (a === b ? 5 : 0) + keep * 3 + r();
      if (sc > bs) { bs = sc; best = m; }
    }
    return best;
  }
  function botPick(st, rnd) { const f = freeDeck(st); return f.length ? f[Math.floor((rnd || Math.random)() * f.length)] : -1; }

  // ---- lo que ve cada jugador (para reconectarse a una partida) ----
  function viewFor(st, p) {
    return {
      mode: st.mode, n: st.n, me: p, round: st.round, phase: st.phase, scores: st.scores.slice(), target: st.cfg.target,
      pos: st.pos, deck: st.deck.map((d) => d.owner), hand: (st.hands[p] || []).slice(), counts: st.hands.map((h) => h.length),
      pozo: st.pozo.length, chain: st.chain.map((c) => ({ p: c.p, tile: c.id, end: c.end })), ends: st.ends,
      turn: st.turn, mustPlay: st.mustPlay, legal: st.turn === p ? legal(st, p) : [], result: st.result
    };
  }

  // quita de los eventos lo que p no debe ver (las fichas de los demás)
  function redact(ev, p) {
    return ev.map((e) => {
      if (e.priv != null && e.priv !== p) { const c = Object.assign({}, e); delete c.tile; delete c.priv; return c; }
      if (e.priv != null) { const c = Object.assign({}, e); delete c.priv; return c; }
      return e;
    });
  }

  return { TILES, MODES, PASE_PTS, CORRIDO_PTS, tileOf, idOf, pips, isDouble, rngFrom, newMatch, startRound, pick, freeDeck, pickDone, legal, canPlay, play, pass, teamOf, botMove, botPick, viewFor, redact };
});
