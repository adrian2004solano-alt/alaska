# Dominó Dominicano

Dominó dominicano **en línea** para el navegador: **parejas** y **1 vs 1**, mesas de **10, 20, 40 y 80 monedas** (ficticias),
**chat** con otros jugadores, **servicio al cliente**, **personalización** (avatar, paño, madera y fichas) y **ranking**.
Reglas dominicanas: pase (25), pase corrido (30), capicúa y tranque.

![Dominó Dominicano](assets/og/og-image.jpg)

## Cómo está armado

- **Lobby** (`index.html`): perfil, monedas y bonos, elegir mesa, chat, personalización, ranking, soporte y perfil.
- **Mesa** (mismo `index.html`, en un lienzo): el juego 3D de siempre, ahora movido por eventos del servidor.
- **Servidor** (`server/`): Node.js sin dependencias externas. Cuentas, monedas, emparejamiento, mesas con la
  computadora de relleno, chat con moderación, tickets de soporte y panel de administración. Base de datos SQLite
  incluida en Node.js.
- **Motor de reglas** (`shared/engine.js` y `shared/room.js`): el mismo código decide las jugadas en el servidor y en el
  modo práctica. El servidor es quien manda, así nadie puede hacer trampa ni inventarse monedas.

```
domino-dominicano/
├── index.html            Lobby + mesa
├── admin.html            Panel de soporte (/admin)
├── reglas.html · terminos.html · privacidad.html · 404.html
├── css/                  game.css (mesa) · lobby.css · pages.css · admin.css
├── js/
│   ├── app/              cargador y arranque
│   ├── lobby/            conexión con el servidor y pantallas del lobby
│   ├── core/ game/ render/   la mesa (dibujo, animaciones, toque y arrastre)
│   └── admin.js
├── shared/               motor de reglas, mesa, avatares y temas (navegador y servidor)
├── server/               servidor: index, hub (tiempo real), api, users, db, moderation, ws, config
├── assets/               iconos, imagen para redes, capturas
├── tests/                engine (3.000 partidas), server (varios jugadores), browser (navegador real)
├── docs/                 SERVIDOR.md (cómo publicarlo), ARQUITECTURA.md, LANZAMIENTO.md
└── Dockerfile
```

## Empezar

```bash
npm start            # http://localhost:3000  (Node.js 22.13 o más nuevo)
npm test             # reglas + servidor
```

Para publicarlo: **[docs/SERVIDOR.md](docs/SERVIDOR.md)**.

## Licencia

Todos los derechos reservados. Ver [LICENSE](LICENSE).
