// Pruebas del servidor: varias personas conectadas a la vez (chat, mesas 1 vs 1 y parejas, monedas, soporte, admin).
// Uso: node tests/server.test.mjs
import { spawn } from 'node:child_process';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = fileURLToPath(new URL('..', import.meta.url));
const PORT = 5288, BASE = `http://localhost:${PORT}`, WSURL = `ws://localhost:${PORT}/ws`;
const dataDir = mkdtempSync(join(tmpdir(), 'domino-test-'));
let fails = 0, passes = 0;
const ok = (n, c, x = '') => { if (c) { passes++; console.log('  ✔', n); } else { fails++; console.log('  ✘', n, x); } };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

let srv;
function startServer() {
  srv = spawn(process.execPath, ['--no-warnings', 'server/index.js'], { cwd: root, env: { ...process.env, PORT: String(PORT), DATA_DIR: dataDir, QUEUE_WAIT_MS: '1500', TIME_SCALE: '0.03', ADMIN_KEY: 'clave-de-prueba', GUEST_PER_HOUR: '1000' }, stdio: ['ignore', 'pipe', 'pipe'] });
  srv.stderr.on('data', (d) => process.stderr.write('[srv] ' + d));
  return new Promise((r) => srv.stdout.on('data', (d) => { if (String(d).includes('http://localhost')) r(); }));
}
async function api(path, body, token, admin) {
  const res = await fetch(BASE + path, { method: body ? 'POST' : 'GET', headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}), ...(admin ? { 'X-Admin-Key': admin } : {}) }, body: body ? JSON.stringify(body) : undefined });
  return { status: res.status, ...(await res.json()) };
}

// Un jugador conectado que juega solo (toma fichas y juega la primera jugada posible)
class Player {
  constructor(name) { this.name = name; this.msgs = []; this.waiters = []; this.free = new Set(); this.mine = 0; }
  async connect(token) {
    if (!token) { const g = await api('/api/guest', {}); token = g.token; this.me = g.me; }
    this.token = token;
    this.ws = new WebSocket(WSURL);
    await new Promise((r, j) => { this.ws.onopen = r; this.ws.onerror = j; });
    this.ws.onmessage = (e) => this.onMsg(JSON.parse(e.data));
    this.send({ t: 'hello', token });
    const w = await this.wait((m) => m.t === 'welcome');
    this.me = w.me; return this;
  }
  send(m) { this.ws.send(JSON.stringify(m)); }
  wait(pred, ms = 20000) {
    const hit = this.msgs.find(pred); if (hit) { this.msgs.splice(this.msgs.indexOf(hit), 1); return Promise.resolve(hit); }
    return new Promise((res, rej) => { const w = { pred, res }; this.waiters.push(w); setTimeout(() => { this.waiters = this.waiters.filter((x) => x !== w); rej(new Error(this.name + ': tiempo agotado')); }, ms); });
  }
  onMsg(m) {
    if (m.t === 'ev') for (const e of m.e) this.onEv(e);
    if (m.t === 'matched') { this.view = m.view; this.seat = m.view.me; this.free = new Set(m.view.deck.map((o, i) => (o < 0 ? i : -1)).filter((i) => i >= 0)); this.mine = m.view.hand.length; if (m.view.phase === 'pick') this.pickLoop(); }
    const w = this.waiters.find((x) => x.pred(m));
    if (w) { this.waiters = this.waiters.filter((x) => x !== w); w.res(m); } else this.msgs.push(m);
  }
  onEv(e) {
    if (this.leaveAfter && e.type === 'turn') { this.send({ t: 'leave' }); this.leaveAfter = false; this.autoplay = false; }
    if (e.type === 'round') { this.free = new Set([...Array(28).keys()]); this.mine = 0; this.events = (this.events || 0) + 1; setTimeout(() => this.pickLoop(), 150); }
    if (e.type === 'pick') { this.free.delete(e.i); if (e.p === this.seat) this.mine++; }
    if (e.type === 'pozo') for (const i of e.idx) this.free.delete(i);
    if (e.type === 'turn' && e.p === this.seat && this.autoplay !== false) {
      setTimeout(() => { if (e.legal && e.legal.length) this.send({ t: 'act', a: { t: 'play', tile: e.legal[0].id, end: e.legal[0].end } }); else this.send({ t: 'act', a: { t: 'pass' } }); }, 20);
    }
  }
  pickLoop() {
    if (this.mine >= 7 || !this.free.size) return;
    const arr = [...this.free], i = arr[Math.floor(Math.random() * arr.length)];
    this.send({ t: 'act', a: { t: 'pick', i } });
    setTimeout(() => this.pickLoop(), 60);
  }
  close() { this.ws.close(); }
}

try {
  await startServer();
  console.log('Cuentas');
  const A = await new Player('A').connect(), B = await new Player('B').connect();
  ok('cuenta de invitado con 500 monedas de bienvenida', A.me.coins === 500 && /^Jugador\d+/.test(A.me.name));
  const reg = await api('/api/register', { name: 'Yoel Prueba', password: 'secreto123' }, A.token);
  ok('ponerle nombre y contraseña a la cuenta', reg.me && reg.me.registered && reg.me.name === 'Yoel Prueba');
  const dup = await api('/api/register', { name: 'yoel prueba', password: 'otraclave' }, B.token);
  ok('no se repiten nombres', dup.status === 400);
  const bad = await api('/api/profile', { name: 'Pendejo' }, B.token);
  ok('nombres groseros no', bad.status === 400);
  const lg = await api('/api/login', { name: 'Yoel Prueba', password: 'secreto123' });
  const lgBad = await api('/api/login', { name: 'Yoel Prueba', password: 'mala' });
  ok('entrar con nombre y contraseña', !!lg.token && lgBad.status === 400);
  const daily = await api('/api/daily', {}, A.token), daily2 = await api('/api/daily', {}, A.token);
  ok('bono diario una vez al día (+100)', daily.coins === 600 && daily2.status === 400);
  const prof = await api('/api/profile', { avatar: 's1.h2.c3.t1.g0.b2.k5', prefs: { felt: 'verde', wood: 'caoba', tiles: 'negro', pips: 'colores' } }, B.token);
  ok('guardar avatar y personalización', prof.me.avatar === 's1.h2.c3.t1.g0.b2.k5' && prof.me.prefs.felt === 'verde' && prof.me.prefs.tiles === 'negro');

  console.log('Chat');
  A.send({ t: 'chat', text: 'Hola mierda, entren a www.estafa.com' });
  const ch = await B.wait((m) => m.t === 'chat');
  ok('el mensaje llega a los demás, sin groserías ni enlaces', ch.m.text.includes('Hola') && !/mierda/i.test(ch.m.text) && ch.m.text.includes('[enlace]'), ch.m.text);
  for (let i = 0; i < 7; i++) A.send({ t: 'chat', text: 'spam ' + i });
  const err = await A.wait((m) => m.t === 'error');
  ok('límite de mensajes seguidos', /rápido/.test(err.msg));
  B.send({ t: 'report', id: ch.m.id });
  ok('reportar un mensaje', !!(await B.wait((m) => m.t === 'notice' && m.kind === 'report')));

  console.log('Mesa 1 vs 1 (dos personas)');
  const coinsA0 = (await api('/api/me', null, A.token)).me.coins, coinsB0 = (await api('/api/me', null, B.token)).me.coins;
  A.send({ t: 'queue', mode: 'duelo', stake: 20 }); B.send({ t: 'queue', mode: 'duelo', stake: 20 });
  const [mA, mB] = await Promise.all([A.wait((m) => m.t === 'matched'), B.wait((m) => m.t === 'matched')]);
  ok('se juntan en la misma mesa', mA.view.room.id === mB.view.room.id && mA.view.seats.every((s) => !s.bot));
  ok('se cobra la apuesta', (await A.wait((m) => m.t === 'coins' && m.reason === 'apuesta')).coins === coinsA0 - 20);
  A.send({ t: 'chat', scope: 'mesa', text: '¡Buena suerte!' });
  ok('chat de la mesa', (await B.wait((m) => m.t === 'tchat')).text === '¡Buena suerte!');
  const [eA] = await Promise.all([A.wait((m) => m.t === 'end', 120000), B.wait((m) => m.t === 'end', 120000)]);
  await sleep(300);
  const fA = (await api('/api/me', null, A.token)).me.coins, fB = (await api('/api/me', null, B.token)).me.coins;
  const winA = eA.info.winnerTeam === eA.info.players.find((p) => p.seat === A.seat).team;
  ok('la partida termina y el ganador cobra el doble', (winA ? fA === coinsA0 + 20 && fB === coinsB0 - 20 : fB === coinsB0 + 20 && fA === coinsA0 - 20), JSON.stringify({ coinsA0, coinsB0, fA, fB, winA, scores: eA.info.scores }));
  const hist = await api('/api/history', null, winA ? A.token : B.token);
  ok('historial de monedas', hist.items.some((x) => x.reason === 'premio' && x.delta === 40));

  console.log('Parejas con la computadora');
  const C = await new Player('C').connect();
  C.send({ t: 'queue', mode: 'parejas', stake: 10 });
  const mC = await C.wait((m) => m.t === 'matched', 8000);
  ok('si no hay gente, se completa con jugadores de la computadora', mC.view.seats.filter((s) => s.bot).length === 3 && mC.view.n === 4);
  const eC = await C.wait((m) => m.t === 'end', 120000);
  ok('partida de parejas completa hasta 200', Math.max(...eC.info.scores) >= 200, JSON.stringify(eC.info.scores));

  console.log('Abandonar y reconectar');
  const D = await new Player('D').connect(), E2 = await new Player('E').connect();
  D.send({ t: 'queue', mode: 'duelo', stake: 40 }); E2.send({ t: 'queue', mode: 'duelo', stake: 40 });
  await Promise.all([D.wait((m) => m.t === 'matched'), E2.wait((m) => m.t === 'matched')]);
  D.close(); await sleep(400);
  const D2 = await new Player('D2').connect(D.token);
  const back = await D2.wait((m) => m.t === 'matched' && m.resume, 5000);
  ok('al volver a entrar retomas tu mesa', back.view.room.id && back.view.hand.length >= 0);
  D2.autoplay = false; D2.send({ t: 'leave' });
  ok('abandonar la mesa', !!(await D2.wait((m) => m.t === 'left')));
  const eE = await E2.wait((m) => m.t === 'end', 120000);
  ok('la mesa sigue con la computadora en lugar de quien se fue', eE.info.players.some((p) => p.left));
  const dCoins = (await api('/api/me', null, D.token)).me.coins;
  ok('quien abandona pierde su apuesta', dCoins === 500 - 40, dCoins);

  console.log('Servicio al cliente y administración');
  const tk = await api('/api/tickets', { category: 'Monedas', subject: 'No me llegó el bono', text: 'Jugué ayer y no me dieron el bono diario.' }, B.token);
  ok('crear una consulta', tk.id > 0);
  const noKey = await api('/api/admin/stats', null, null, 'mala');
  ok('el panel pide la clave', noKey.status === 401);
  const st = await api('/api/admin/stats', null, null, 'clave-de-prueba');
  ok('estadísticas del panel', st.users >= 5 && st.openTickets >= 1 && st.openReports >= 1, JSON.stringify(st));
  await api(`/api/admin/tickets/${tk.id}/reply`, { text: 'Ya te los acreditamos. ¡Suerte!' }, null, 'clave-de-prueba');
  const note = await B.wait((m) => m.t === 'notice' && m.kind === 'ticket');
  const th = await api(`/api/tickets/${tk.id}`, null, B.token);
  ok('la respuesta de soporte llega al jugador', !!note && th.messages.length === 2 && th.messages[1].admin === 1 && th.ticket.status === 'respondido');
  const adj = await api(`/api/admin/users/${B.me.id}/coins`, { delta: 100, reason: 'bono' }, null, 'clave-de-prueba');
  ok('ajustar monedas desde el panel', adj.coins > 0 && (await B.wait((m) => m.t === 'coins' && m.reason === 'ajuste de soporte')).delta === 100);
  await api(`/api/admin/users/${B.me.id}/mute`, { minutes: 10 }, null, 'clave-de-prueba');
  B.send({ t: 'chat', text: 'hola' });
  ok('silenciar a un jugador', /No puedes escribir/.test((await B.wait((m) => m.t === 'error')).msg));
  const lb = await api('/api/leaderboard');
  ok('ranking', lb.items.length >= 2);

  console.log('Reinicio con una partida a medias');
  const F = await new Player('F').connect();
  F.autoplay = false;
  F.send({ t: 'queue', mode: 'duelo', stake: 80 });
  await F.wait((m) => m.t === 'matched', 8000);
  const fBefore = (await api('/api/me', null, F.token)).me.coins;
  srv.kill('SIGTERM'); await sleep(800); await startServer();
  const fAfter = (await api('/api/me', null, F.token)).me.coins;
  ok('se devuelve la apuesta de la partida interrumpida', fBefore === 420 && fAfter === 500, fBefore + ' → ' + fAfter);

  console.log('Sitio');
  for (const [p, code] of [['/', 200], ['/reglas', 200], ['/server/db.js', 404], ['/data/domino.db', 404], ['/../package.json', 404], ['/shared/engine.js', 200]]) {
    const r = await fetch(BASE + p); ok(`${p} → ${code}`, r.status === code, r.status);
  }
  for (const pl of [A, B, C, D2, E2, F]) try { pl.close(); } catch {}
} catch (e) { fails++; console.error('ERROR', e); }
finally { srv.kill('SIGTERM'); await sleep(300); rmSync(dataDir, { recursive: true, force: true }); }
console.log(`\n${passes} bien, ${fails} con fallas`);
process.exit(fails ? 1 : 0);
