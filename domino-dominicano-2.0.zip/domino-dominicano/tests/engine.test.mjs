// Pruebas del motor de reglas: miles de partidas completas entre jugadores de la computadora.
// Uso: node tests/engine.test.mjs
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const E = require('../shared/engine.js');
let fails = 0; const ok = (n, c, x = '') => { if (c) console.log('  ✔', n); else { fails++; console.log('  ✘', n, x); } };

function runMatch(mode, seed) {
  const st = E.newMatch(mode, { seed });
  const stats = { rounds: 0, corridos: 0, pases: 0, caps: 0, tranques: 0, draws: 0, errors: [], bonus: 0 };
  let guard = 0;
  while (st.phase !== 'over' && guard++ < 200) {
    E.startRound(st); stats.rounds++;
    // tomar fichas por turnos
    let p = 0, g2 = 0;
    while (st.phase === 'pick' && g2++ < 100) { if (st.hands[p].length < st.cfg.deal) E.pick(st, p, E.botPick(st)); p = (p + 1) % st.n; }
    const scoreBefore = st.scores.slice();
    let g3 = 0, bonusPts = 0;
    while (st.phase === 'play' && g3++ < 500) {
      const q = st.turn, m = E.botMove(st, q);
      // invariante: las fichas siempre suman 28
      const n = st.hands.reduce((s, h) => s + h.length, 0) + st.chain.length + st.pozo.length + st.deck.filter(d => d.owner < 0).length;
      if (n !== 28) stats.errors.push('fichas ' + n);
      const ev = m ? E.play(st, q, m.id, m.end) : E.pass(st, q);
      for (const e of ev) {
        if (e.type === 'corrido' && !e.tranque) { stats.corridos++; bonusPts += e.pts; }
        if (e.type === 'pass') { stats.pases++; if (e.bonus) bonusPts += e.bonus.pts; }
        if (e.type === 'draw') stats.draws++;
        if (e.type === 'roundEnd') { if (e.cap) stats.caps++; if (e.kind === 'block') stats.tranques++;
          if (e.cap && e.nums[0] === e.nums[1]) stats.errors.push('capicúa con puntas iguales');
          const gained = e.scores[0] + e.scores[1] - scoreBefore[0] - scoreBefore[1];
          if (gained !== bonusPts + e.pts) stats.errors.push('puntos no cuadran ' + gained + ' vs ' + (bonusPts + e.pts)); }
      }
      // la cola siempre encaja
      for (let i = 1; i < st.chain.length; i++) { /* verificado por legal() */ }
    }
    if (st.phase === 'play') stats.errors.push('mano sin terminar');
    stats.bonus += bonusPts;
  }
  return { st, stats };
}

for (const mode of ['parejas', 'duelo']) {
  console.log('Modo', mode);
  const tot = { matches: 0, rounds: 0, corridos: 0, pases: 0, caps: 0, tranques: 0, draws: 0, errors: [] };
  for (let s = 1; s <= 1500; s++) {
    const { st, stats } = runMatch(mode, s);
    tot.matches++; for (const k of ['rounds', 'corridos', 'pases', 'caps', 'tranques', 'draws']) tot[k] += stats[k];
    tot.errors.push(...stats.errors);
    if (st.phase !== 'over') tot.errors.push('partida sin terminar');
    if (st.winnerTeam == null || st.scores[st.winnerTeam] < st.cfg.target) tot.errors.push('ganador mal ' + st.scores);
  }
  console.log('   ', JSON.stringify({ ...tot, errors: tot.errors.length }));
  ok(`1500 partidas completas sin errores (${tot.rounds} manos)`, tot.errors.length === 0, tot.errors.slice(0, 5).join(' | '));
  if (mode === 'parejas') ok('hay pases corridos y capicúas', tot.corridos > 0 && tot.caps > 0);
  if (mode === 'duelo') ok('se roba del pozo', tot.draws > 0);
}

console.log('Reglas puntuales');
{ // sale el 6|6 en parejas
  const st = E.newMatch('parejas', { seed: 7 }); E.startRound(st);
  let p = 0; while (st.phase === 'pick') { if (st.hands[p].length < 7) E.pick(st, p, E.botPick(st)); p = (p + 1) % 4; }
  const holder = st.hands.findIndex(h => h.includes(27));
  ok('sale quien tiene el 6|6', st.turn === holder && E.legal(st, holder).length === 1 && E.legal(st, holder)[0].id === 27);
  let err = null; try { E.play(st, (holder + 1) % 4, st.hands[(holder + 1) % 4][0], 'C'); } catch (e) { err = e.message; }
  ok('no se puede jugar fuera de turno', !!err);
}
{ // capicúa y no capicúa (montado a mano)
  const st = E.newMatch('parejas', { seed: 1 }); E.startRound(st);
  st.phase = 'play'; st.hands = [[E.idOf(4, 2)], [E.idOf(0, 0), E.idOf(0, 1)], [E.idOf(1, 1)], [E.idOf(1, 3)]];
  st.chain = [{ p: 1, id: E.idOf(4, 2), end: 'C' }]; st.ends = { L: 4, R: 2 }; st.turn = 0;
  const ev = E.play(st, 0, E.idOf(4, 2), 'L');
  ok('capicúa con puntas 4 y 2 jugando 4|2', ev.find(e => e.type === 'roundEnd').cap === true);
  const st2 = E.newMatch('parejas', { seed: 1 }); E.startRound(st2);
  st2.phase = 'play'; st2.hands = [[E.idOf(6, 3)], [E.idOf(0, 0)], [E.idOf(1, 1)], [E.idOf(1, 3)]]; st2.ends = { L: 6, R: 6 }; st2.chain = [{ p: 1, id: 27, end: 'C' }]; st2.turn = 0;
  const ev2 = E.play(st2, 0, E.idOf(6, 3), 'L');
  ok('no es capicúa con puntas iguales', ev2.find(e => e.type === 'roundEnd').cap === false);
}
{ // pase corrido y pase normal
  const st = E.newMatch('parejas', { seed: 1 }); E.startRound(st);
  st.phase = 'play'; st.hands = [[E.idOf(5, 5), E.idOf(5, 3), E.idOf(2, 2)], [E.idOf(0, 0), E.idOf(0, 1)], [E.idOf(1, 1), E.idOf(1, 2)], [E.idOf(1, 3), E.idOf(3, 3)]];
  st.chain = [{ p: 3, id: E.idOf(5, 4), end: 'C' }]; st.ends = { L: 5, R: 4 }; st.turn = 0; st.scores = [0, 0];
  st.hands[0] = [E.idOf(4, 5), E.idOf(5, 3), E.idOf(2, 2)];
  const ev = E.play(st, 0, E.idOf(4, 5), 'R');
  const c = ev.find(e => e.type === 'corrido');
  ok('pase corrido: +30 y vuelve a jugar quien jugó', c && c.pts === 30 && st.scores[0] === 30 && st.turn === 0);
  const st2 = E.newMatch('parejas', { seed: 1 }); E.startRound(st2);
  st2.phase = 'play'; st2.hands = [[E.idOf(4, 5), E.idOf(2, 2)], [E.idOf(0, 0), E.idOf(0, 1)], [E.idOf(1, 5), E.idOf(1, 2)], [E.idOf(1, 3), E.idOf(3, 3)]];
  st2.chain = [{ p: 3, id: E.idOf(5, 4), end: 'C' }]; st2.ends = { L: 5, R: 4 }; st2.turn = 0;
  E.play(st2, 0, E.idOf(4, 5), 'R');
  const ev2 = E.pass(st2, 1);
  ok('pase normal: +25 para el equipo de quien jugó', ev2[0].bonus && ev2[0].bonus.team === 0 && st2.scores[0] === 25);
}
{ // duelo: el pozo
  const st = E.newMatch('duelo', { seed: 3 }); E.startRound(st);
  let p = 0; while (st.phase === 'pick') { if (st.hands[p].length < 7) E.pick(st, p, E.botPick(st)); p = 1 - p; }
  ok('duelo: 7 y 7 y 14 en el pozo', st.hands[0].length === 7 && st.hands[1].length === 7 && st.pozo.length === 14);
  const v = E.viewFor(st, 0), red = E.redact([{ type: 'pick', p: 1, i: 0, tile: 5, priv: 1 }], 0);
  ok('no se ven las fichas del rival', red[0].tile === undefined && v.hand.length === 7 && !('hands' in v));
}
console.log(fails ? `\n${fails} con fallas` : '\nTodo bien');
process.exit(fails ? 1 : 0);
