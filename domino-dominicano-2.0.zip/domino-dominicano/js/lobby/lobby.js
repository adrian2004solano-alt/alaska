// Dominó Dominicano · lobby: perfil, monedas, mesas, chat, personalización, ranking, soporte.
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const h=(tag,attrs,...kids)=>{const e=document.createElement(tag);for(const k in attrs||{}){if(k==='class')e.className=attrs[k];else if(k.startsWith('on'))e.addEventListener(k.slice(2),attrs[k]);else if(attrs[k]!=null)e.setAttribute(k,attrs[k])}
 for(const c of kids.flat())if(c!=null)e.append(c.nodeType?c:document.createTextNode(String(c)));return e};
const fmt=n=>Number(n||0).toLocaleString('es-DO');
const ago=t=>{const s=(Date.now()-t)/1000;return s<60?'ahora':s<3600?Math.floor(s/60)+' min':s<86400?Math.floor(s/3600)+' h':new Date(t).toLocaleDateString('es-DO')};
const LOBBY={me:null,mode:'parejas',stake:10,stakes:[10,20,40,80],online:false};
function toastL(txt,kind){const t=h('div',{class:'toast '+(kind||'')},txt);$('#toasts').append(t);setTimeout(()=>t.remove(),4200)}
function dialog(title,body,buttons){$('#dlgT').textContent=title;const b=$('#dlgB');b.innerHTML='';if(typeof body==='string')b.append(h('p',{},body));else if(body)b.append(body);
 const r=$('#dlgBtns');r.innerHTML='';for(const[txt,cls,fn]of buttons)r.append(h('button',{class:'btn '+cls,onclick:()=>{$('#dialog').hidden=true;fn&&fn()}},txt));$('#dialog').hidden=false}

// ---- secciones ----
function showView(v){$$('.tabs button').forEach(b=>b.classList.toggle('on',b.dataset.v===v));$$('.view').forEach(s=>s.hidden=s.id!=='v-'+v);
 if(v==='ranking')loadRanking();if(v==='soporte')loadTickets();if(v==='perfil')renderProfile();$('#lobby').scrollTop=0}
$$('.tabs button').forEach(b=>b.onclick=()=>showView(b.dataset.v));

// ---- perfil y monedas ----
function setMe(me){LOBBY.me=me;try{localStorage.setItem('domino.me',JSON.stringify({name:me.name,avatar:me.avatar}))}catch(e){}
 $('#coins').textContent=fmt(me.coins);$('#meName').textContent=me.name;$('#meAv').src=DomProfile.dataUri(me.avatar,68);
 $('#dailyDot').hidden=!(me.daily||me.rescue);
 if(me.prefs&&JSON.stringify(me.prefs)!==JSON.stringify(PREFS)){savePrefsLocal(me.prefs);applyTheme(me.prefs,true)}
 renderStakes();if(!$('#v-perfil').hidden)renderProfile()}
$('#coinsBtn').onclick=async()=>{const me=LOBBY.me;if(!LOBBY.online||!me)return;
 if(me.daily){try{const r=await NET.api('/api/daily',{});toastL('¡Bono diario! +'+r.amount+' monedas','good')}catch(e){toastL(e.message,'bad')}return}
 if(me.rescue){try{const r=await NET.api('/api/rescue',{});toastL('Bono de rescate: +'+r.amount+' monedas','good')}catch(e){toastL(e.message,'bad')}return}
 toastL('Tienes '+fmt(me.coins)+' monedas. El bono diario se renueva cada día.')};
$('#meBtn').onclick=()=>showView('perfil');

// ---- elegir mesa ----
function renderStakes(){const box=$('#stakes');box.innerHTML='';
 for(const s of LOBBY.stakes){const poor=LOBBY.online&&LOBBY.me&&LOBBY.me.coins<s;
  box.append(h('button',{class:'stake'+(s===LOBBY.stake?' on':''),role:'radio','aria-checked':s===LOBBY.stake,disabled:poor?'':null,onclick:()=>{LOBBY.stake=s;renderStakes()}},
   h('span',{class:'chip'},s),h('small',{},'ganas '+(s*2))))}
 $('#playBtn').disabled=!LOBBY.online}
$$('.mode').forEach(b=>b.onclick=()=>{LOBBY.mode=b.dataset.mode;$$('.mode').forEach(x=>{x.classList.toggle('on',x===b);x.setAttribute('aria-checked',x===b)})});
$('#playBtn').onclick=()=>{if(!LOBBY.online)return toastL('Sin conexión con el servidor. Prueba el modo práctica.','bad');
 if(LOBBY.me.coins<LOBBY.stake)return toastL('No te alcanzan las monedas para esa mesa.','bad');
 NET.send({t:'queue',mode:LOBBY.mode,stake:LOBBY.stake})};
$('#cancelSearch').onclick=()=>{NET.send({t:'unqueue'});$('#searching').hidden=true};
$('#practiceBtn').onclick=()=>enterPractice(LOBBY.mode);
NET.on('queued',m=>{$('#searchTxt').textContent=(m.mode==='duelo'?'1 vs 1':'Parejas')+' · mesa de '+m.stake+' monedas';$('#searching').hidden=false});
NET.on('unqueued',()=>{$('#searching').hidden=true});

// ---- chat ----
function chatItem(m){const mine=LOBBY.me&&m.uid===LOBBY.me.id;
 return h('li',{class:'msg','data-id':m.id},h('img',{src:DomProfile.dataUri(m.avatar,64),alt:''}),
  h('div',{},h('span',{class:'who'},m.name),h('span',{class:'when'},ago(m.ts)),mine?null:h('button',{class:'rep',title:'Reportar mensaje',onclick:()=>reportMsg(m)},'reportar'),h('p',{},m.text)))}
function addChat(m){const box=$('#msgs'),near=box.scrollHeight-box.scrollTop-box.clientHeight<80;box.append(chatItem(m));while(box.children.length>120)box.firstChild.remove();if(near)box.scrollTop=box.scrollHeight}
function reportMsg(m){dialog('Reportar mensaje','"'+m.text+'" — '+m.name,[['Cancelar','ghost'],['Reportar','gold',()=>NET.send({t:'report',id:m.id})]])}
$('#chatForm').onsubmit=e=>{e.preventDefault();const v=$('#chatIn').value.trim();if(!v)return;if(!LOBBY.online)return toastL('El chat necesita conexión con el servidor.','bad');NET.send({t:'chat',text:v});$('#chatIn').value=''};
NET.on('chat',m=>addChat(m.m));
NET.on('chatdel',m=>{const li=$('#msgs [data-id="'+m.id+'"]');if(li)li.remove()});

// ---- personalización ----
let avDraft=null;
function renderAvatar(){const o=DomProfile.parse(avDraft);$('#avBig').src=DomProfile.dataUri(avDraft,150);const box=$('#avParts');box.innerHTML='';
 for(const k of DomProfile.ORDER){const P=DomProfile.PARTS[k],opts=h('div',{class:'av-opts'});
  for(let i=0;i<P.n;i++){const preview=Object.assign({},o,{[k]:i});
   const sw=k==='s'?DomProfile.SKIN[i]:k==='c'?DomProfile.HAIR[i]:k==='k'?DomProfile.BG[i]:null;
   const b=h('button',{class:i===o[k]?'on':'',title:P.names?P.names[i]:P.label+' '+(i+1),'aria-label':P.label+': '+(P.names?P.names[i]:i+1),onclick:()=>{avDraft=DomProfile.encode(preview);renderAvatar()}});
   if(sw)b.style.background=sw;else b.append(h('img',{src:DomProfile.dataUri(DomProfile.encode(preview),34),alt:'',width:30,height:30,style:'border-radius:50%'}));
   opts.append(b)}
  box.append(h('div',{class:'av-part'},h('span',{},P.label),opts))}}
$('#avRandom').onclick=()=>{avDraft=DomProfile.random();renderAvatar()};
$('#avSave').onclick=async()=>{if(!LOBBY.online){saveLocalMe({avatar:avDraft});return toastL('Avatar guardado en este dispositivo.','good')}
 try{const r=await NET.api('/api/profile',{avatar:avDraft});setMe(r.me);toastL('Avatar guardado.','good')}catch(e){toastL(e.message,'bad')}};
const SWATCH={felt:{bandera:'linear-gradient(90deg,#002d62 0 44%,#eee 44% 56%,#ce1126 56%)',verde:'radial-gradient(circle,#2f7a4f,#0f3a22)',azul:'radial-gradient(circle,#2c5a9a,#0e2246)',vino:'radial-gradient(circle,#7d2a35,#36090f)'},
 wood:{nogal:'repeating-linear-gradient(90deg,#a8683a 0 6px,#6b3f1e 6px 9px,#93582e 9px 15px)',caoba:'repeating-linear-gradient(90deg,#9e4228 0 6px,#561a0c 6px 9px,#82321d 9px 15px)',roble:'repeating-linear-gradient(90deg,#d4a66c 0 6px,#9a6a36 6px 9px,#c4945a 9px 15px)',ebano:'repeating-linear-gradient(90deg,#523a2c 0 6px,#1a120d 6px 9px,#3d2a20 9px 15px)'},
 tiles:{marfil:'linear-gradient(#fffdf4,#e6e1cf)',perla:'linear-gradient(#ffffff,#e3e6ea)',negro:'linear-gradient(#3a3a3d,#1b1b1d)'},
 pips:{clasico:'radial-gradient(circle at 30% 50%,#1b1b1b 0 7px,transparent 8px),radial-gradient(circle at 70% 50%,#1b1b1b 0 7px,transparent 8px),#f5ecd9',colores:'radial-gradient(circle at 20% 50%,#d62828 0 7px,transparent 8px),radial-gradient(circle at 40% 50%,#1d6fd1 0 7px,transparent 8px),radial-gradient(circle at 60% 50%,#2b9348 0 7px,transparent 8px),radial-gradient(circle at 80% 50%,#e8890c 0 7px,transparent 8px),#f5ecd9'}};
const THEME_TITLES={felt:'Paño',wood:'Madera',tiles:'Fichas',pips:'Puntos'};
function renderThemes(){const box=$('#themes');box.innerHTML='';
 for(const k of['felt','wood','tiles','pips']){const opts=h('div',{class:'theme-opts'});
  for(const[key,label]of Object.entries(DomProfile.THEMES[k]))opts.append(h('button',{class:'theme-opt'+(PREFS[k]===key?' on':''),onclick:()=>setPref(k,key)},h('i',{class:'sw',style:'background:'+SWATCH[k][key]}),h('span',{},label)));
  box.append(h('div',{class:'theme-row'},h('h3',{},THEME_TITLES[k]),opts))}}
function savePrefsLocal(p){try{localStorage.setItem('domino.prefs',JSON.stringify(p))}catch(e){}}
async function setPref(k,v){const p=Object.assign({},PREFS,{[k]:v});applyTheme(p,true);savePrefsLocal(PREFS);renderThemes();
 if(LOBBY.online){try{await NET.api('/api/profile',{prefs:PREFS})}catch(e){}}}
function saveLocalMe(o){const me=Object.assign({},LOBBY.me||{},o);setMe(me)}

// ---- ranking ----
async function loadRanking(){const box=$('#rank');if(!LOBBY.online){box.innerHTML='';box.append(h('li',{},'El ranking necesita conexión con el servidor.'));return}
 try{const r=await NET.api('/api/leaderboard');box.innerHTML='';
  r.items.forEach((u,i)=>box.append(h('li',{class:LOBBY.me&&u.id===LOBBY.me.id?'me':''},h('span',{class:'pos'},i+1),h('img',{src:DomProfile.dataUri(u.avatar,76),alt:''}),
   h('span',{class:'nm'},u.name,h('small',{},fmt(u.wins)+' ganadas de '+fmt(u.games))),h('span',{class:'val'},h('i',{class:'coin'}),fmt(u.coins)))));
  if(!r.items.length)box.append(h('li',{},'Todavía nadie ha jugado. ¡Sé el primero!'))}catch(e){toastL(e.message,'bad')}}

// ---- soporte ----
const FAQ=[['¿Las monedas cuestan dinero?','No. Las monedas son ficticias: te regalamos 500 al empezar y 100 cada día con el bono diario. No se compran ni se cambian por dinero.'],
 ['Me quedé sin monedas, ¿qué hago?','Toca tu saldo arriba: si tienes menos de 10 monedas puedes cobrar un bono de rescate cada 6 horas, además del bono diario.'],
 ['¿Cómo funcionan las mesas?','Eliges Parejas o 1 vs 1 y un monto (10, 20, 40 u 80). Al empezar se cobra el monto a cada jugador; el que gana (o la pareja que gana) recibe el doble.'],
 ['¿Contra quién juego?','Contra otras personas conectadas. Si en unos segundos no aparecen suficientes, la mesa se completa con jugadores de la computadora, marcados como BOT.'],
 ['¿Qué pasa si se me cae el internet?','Tu puesto te espera: la computadora juega por ti mientras vuelves y, al entrar otra vez, regresas a tu mesa. Si sales con el botón de salir, pierdes el monto de la mesa.'],
 ['¿Cómo guardo mi cuenta?','En Perfil, ponle nombre y contraseña a tu cuenta. Así puedes entrar desde otro teléfono o computadora sin perder tus monedas.'],
 ['Alguien me falta el respeto en el chat','Toca "reportar" en su mensaje o escríbenos aquí con el tema "Reportar a un jugador". Revisamos todos los reportes.']];
function renderFaq(){const box=$('#faq');box.innerHTML='';for(const[q,a]of FAQ)box.append(h('details',{},h('summary',{},q),h('p',{},a)))}
async function loadTickets(){const box=$('#tickets');box.innerHTML='';if(!LOBBY.online){box.append(h('li',{class:'fine'},'Para escribirle a soporte necesitas conexión.'));return}
 try{const r=await NET.api('/api/tickets');if(!r.items.length)box.append(h('li',{class:'fine'},'Aún no tienes consultas.'));
  for(const t of r.items)box.append(h('li',{},h('button',{onclick:()=>openTicket(t.id)},h('span',{},(t.unread?'● ':'')+t.subject,h('br'),h('small',{class:'fine'},t.category+' · '+ago(t.updated))),h('span',{class:'tag '+t.status},t.status))));
  $('#supDot').hidden=!r.items.some(t=>t.unread)}catch(e){toastL(e.message,'bad')}}
async function openTicket(id){const th=$('#thread');th.hidden=false;th.innerHTML='';
 try{const r=await NET.api('/api/tickets/'+id);th.append(h('h3',{},r.ticket.subject));
  for(const m of r.messages)th.append(h('div',{class:'bubble'+(m.admin?' admin':'')},h('small',{},(m.admin?'Soporte':'Tú')+' · '+ago(m.created)),m.text));
  if(r.ticket.status!=='cerrado'){const inp=h('textarea',{rows:2,maxlength:2000,placeholder:'Responder…','aria-label':'Responder'});
   th.append(h('form',{class:'form',onsubmit:async e=>{e.preventDefault();if(!inp.value.trim())return;try{await NET.api('/api/tickets/'+id+'/messages',{text:inp.value});openTicket(id)}catch(err){toastL(err.message,'bad')}}},inp,h('button',{class:'btn gold'},'Enviar')))}
  loadTicketsQuiet()}catch(e){toastL(e.message,'bad')}}
async function loadTicketsQuiet(){try{const r=await NET.api('/api/tickets');$('#supDot').hidden=!r.items.some(t=>t.unread)}catch(e){}}
$('#ticketForm').onsubmit=async e=>{e.preventDefault();if(!LOBBY.online)return toastL('Sin conexión con el servidor.','bad');
 try{await NET.api('/api/tickets',{category:$('#tkCat').value,subject:$('#tkSubj').value,text:$('#tkText').value});$('#tkSubj').value='';$('#tkText').value='';toastL('Recibimos tu consulta. Te responderemos aquí mismo.','good');loadTickets()}catch(err){toastL(err.message,'bad')}};

// ---- perfil ----
async function renderProfile(){const me=LOBBY.me;if(!me)return;
 $('#profAv').src=DomProfile.dataUri(me.avatar,84);$('#profName').textContent=me.name;
 $('#profKind').textContent=!LOBBY.online?'Sin conexión':me.registered?'Cuenta guardada con contraseña':'Cuenta de invitado: ponle contraseña para no perder tus monedas';
 const st=$('#stats');st.innerHTML='';for(const[v,l]of[[fmt(me.coins),'monedas'],[fmt(me.games),'partidas'],[fmt(me.wins),'ganadas'],[me.games?Math.round(100*me.wins/me.games)+'%':'—','efectividad']])st.append(h('div',{class:'stat'},h('b',{},v),h('span',{},l)));
 $('#nameIn').value=me.name;
 const box=$('#accountBox');box.innerHTML='';
 if(LOBBY.online&&!me.registered){const n=h('input',{maxlength:16,value:me.name,autocomplete:'username'}),p=h('input',{type:'password',minlength:6,autocomplete:'new-password'});
  box.append(h('h3',{},'Guardar mi cuenta'),h('form',{class:'form',onsubmit:async e=>{e.preventDefault();try{const r=await NET.api('/api/register',{name:n.value,password:p.value});setMe(r.me);toastL('Cuenta guardada. Ya puedes entrar desde cualquier lugar.','good')}catch(err){toastL(err.message,'bad')}}},
   h('label',{},'Nombre',n),h('label',{},'Contraseña (mínimo 6)',p),h('button',{class:'btn gold'},'Guardar cuenta')))}
 if(LOBBY.online){const n=h('input',{maxlength:16,autocomplete:'username'}),p=h('input',{type:'password',autocomplete:'current-password'});
  box.append(h('h3',{},'¿Ya tienes cuenta?'),h('form',{class:'form',onsubmit:async e=>{e.preventDefault();try{const r=await NET.api('/api/login',{name:n.value,password:p.value});NET.setToken(r.token);location.reload()}catch(err){toastL(err.message,'bad')}}},
   h('label',{},'Nombre',n),h('label',{},'Contraseña',p),h('button',{class:'btn ghost'},'Entrar')));
  if(me.registered)box.append(h('div',{class:'row'},h('button',{class:'btn ghost',onclick:async()=>{try{await NET.api('/api/logout',{})}catch(e){}NET.logout();location.reload()}},'Cerrar sesión')))}
 const lg=$('#ledger');lg.innerHTML='';
 if(LOBBY.online)try{const r=await NET.api('/api/history');for(const x of r.items)lg.append(h('li',{},h('span',{},x.reason,h('br'),h('small',{class:'fine'},ago(x.created))),h('span',{class:x.delta>=0?'pos':'neg'},(x.delta>=0?'+':'')+fmt(x.delta))))}catch(e){}}
$('#nameForm').onsubmit=async e=>{e.preventDefault();const v=$('#nameIn').value;const err=DomProfile.checkName(v);if(err)return toastL(err,'bad');
 if(!LOBBY.online){saveLocalMe({name:v.trim()});return toastL('Nombre guardado en este dispositivo.','good')}
 try{const r=await NET.api('/api/profile',{name:v});setMe(r.me);toastL('Nombre cambiado.','good')}catch(err2){toastL(err2.message,'bad')}};

// ---- mensajes del servidor ----
NET.on('welcome',m=>{LOBBY.online=true;$('#offline').hidden=true;LOBBY.stakes=m.stakes||LOBBY.stakes;setMe(m.me);$('#msgs').innerHTML='';m.chat.forEach(addChat);
 const box=$('#msgs');box.scrollTop=box.scrollHeight;presence(m.presence);if(m.queue)NET.send({t:'unqueue'});loadTicketsQuiet()});
NET.on('me',m=>setMe(m.me));
NET.on('coins',m=>{if(LOBBY.me){LOBBY.me.coins=m.coins;setMe(LOBBY.me)}if(m.reason==='ajuste de soporte')toastL('Soporte ajustó tus monedas: '+(m.delta>0?'+':'')+m.delta,'good')});
NET.on('presence',presence);
function presence(p){if(!p)return;$('#online span').textContent=fmt(p.online)+' en línea'}
NET.on('status',on=>{LOBBY.online=on;$('#offline').hidden=on;renderStakes()});
NET.on('error',m=>{toastL(m.msg,'bad');if(m.code==='coins')$('#searching').hidden=true});
NET.on('notice',m=>{toastL(m.msg,'good');if(m.kind==='ticket')$('#supDot').hidden=false});
NET.on('banned',m=>dialog('Cuenta suspendida',m.reason||'Tu cuenta fue suspendida. Escríbenos si crees que es un error.',[['Entendido','gold']]));

function initLobby(){avDraft=(LOBBY.me&&LOBBY.me.avatar)||DomProfile.random();renderAvatar();renderThemes();renderFaq();renderStakes()}
