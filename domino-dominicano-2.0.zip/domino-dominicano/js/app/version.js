// Versión de la app. Súbela en cada publicación (y la de sw.js) para que los jugadores reciban la versión nueva.
const APP_VERSION = '2.0.0';
