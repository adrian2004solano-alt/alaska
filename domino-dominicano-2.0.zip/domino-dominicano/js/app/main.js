// Dominó Dominicano · arranque: lobby, entrar y salir de la mesa, fin de partida.
(function boot(){
 try{if(localStorage.getItem('domino.muted')==='1'){muted=true;document.getElementById('mute').textContent='🔇'}}catch(e){}
 const stageEl=document.getElementById('stage'),lobbyEl=document.getElementById('lobby');
 let inGame=null; // 'online' | 'practice' | null
 function showLobby(){stopLoop();stopPractice();inGame=null;stageEl.hidden=true;lobbyEl.hidden=false;document.getElementById('tchat').hidden=true;document.getElementById('modal').style.display='none'}
 function showGame(kind){inGame=kind;lobbyEl.hidden=true;document.getElementById('searching').hidden=true;stageEl.hidden=false;resize();
  document.getElementById('tchatBtn').hidden=kind!=='online';startLoop()}
 window.enterPractice=mode=>{const me=LOBBY.me||(()=>{try{return JSON.parse(localStorage.getItem('domino.me'))}catch(e){return null}})()||{name:'Tú',avatar:DomProfile.random()};
  showGame('practice');startPractice(mode,me)};
 // en línea: el servidor nos sentó en una mesa
 NET.on('matched',m=>{const v=m.view;showGame('online');ACT=a=>NET.send({t:'act',a});
  enterTable({mode:v.room.mode,me:v.me,seats:v.seats,stake:v.room.stake,online:true,view:m.resume?v:null});
  if(!m.resume&&v.phase==='pick'&&v.round===1&&!EVQ.length)EVQ.push({type:'round',round:1,pos:v.pos,scores:v.scores,target:v.target})});
 ['ev','seat','end','reject','tchat'].forEach(t=>NET.on(t,m=>{if(inGame==='online')tableMsg(m)}));
 NET.on('left',()=>{if(inGame==='online')showLobby()});
 // fin de la partida
 onMatchEnd=info=>{const mine=info.players.find(p=>p.seat===ME),won=mine&&info.winnerTeam===mine.team,s=myScores(info.scores);
  document.getElementById('mt').textContent=won?'🏆 ¡Ganaste la partida!':'Perdiste esta partida';
  const coins=info.stake?(won?'+'+info.stake*2+' monedas':'−'+info.stake+' monedas'):'Práctica (sin monedas)';
  document.getElementById('mb').innerHTML='<p class="res '+(won?'win':'lose')+'">'+s[0]+' – '+s[1]+'</p><p>'+coins+'</p>';
  const row=document.getElementById('mbtns');row.innerHTML='';
  const again=document.createElement('button');again.textContent='Jugar otra vez';
  again.onclick=()=>{document.getElementById('modal').style.display='none';if(inGame==='practice')startPractice(MODE,LOBBY.me||{name:'Tú'});else{showLobby();NET.send({t:'queue',mode:info.mode,stake:info.stake})}};
  const back=document.createElement('button');back.textContent='Volver al lobby';back.style.background='#d8cfbd';back.onclick=showLobby;
  row.append(again,back);document.getElementById('modal').style.display='flex'};
 // salir de la mesa
 document.getElementById('menuBtn').onclick=()=>{
  if(inGame==='practice'||lastEnd)return showLobby();
  document.getElementById('mt').textContent='¿Salir de la mesa?';
  document.getElementById('mb').innerHTML='<p>Si sales ahora pierdes las '+STAKE+' monedas de esta mesa y la computadora juega en tu lugar.</p>';
  const row=document.getElementById('mbtns');row.innerHTML='';
  const stay=document.createElement('button');stay.textContent='Seguir jugando';stay.onclick=()=>document.getElementById('modal').style.display='none';
  const go=document.createElement('button');go.textContent='Salir';go.style.background='#d8cfbd';go.onclick=()=>{NET.send({t:'leave'});showLobby()};
  row.append(stay,go);document.getElementById('modal').style.display='flex'};
 // chat de la mesa
 const QUICK=['¡Buena!','¡Capicúa!','Juega rápido','¡Tranque!','Ay mi madre','Pásame esa','¡Dominó!','Buena partida'];
 const tq=document.getElementById('quick');QUICK.forEach(q=>{const b=document.createElement('button');b.type='button';b.textContent=q;b.onclick=()=>NET.send({t:'chat',scope:'mesa',text:q});tq.append(b)});
 document.getElementById('tchatBtn').onclick=()=>{const el=document.getElementById('tchat');el.hidden=!el.hidden;document.getElementById('tchatDot').hidden=true};
 document.getElementById('tchatForm').onsubmit=e=>{e.preventDefault();const i=document.getElementById('tchatIn');if(i.value.trim())NET.send({t:'chat',scope:'mesa',text:i.value});i.value=''};
 window.onTableChat=(m,s)=>{const li=document.createElement('li');const b=document.createElement('b');b.textContent=(s===0?'Tú':m.name)+': ';li.append(b,document.createTextNode(m.text));
  const box=document.getElementById('tmsgs');box.append(li);box.scrollTop=box.scrollHeight;if(document.getElementById('tchat').hidden&&s!==0)document.getElementById('tchatDot').hidden=false};

 // arranque: cuenta y conexión; si el servidor no está, modo sin conexión (práctica)
 initLobby();
 (async()=>{
  let me=null;
  try{me=await NET.ensureAccount();setMe(me);NET.connect()}
  catch(e){LOBBY.online=false;document.getElementById('offline').hidden=false;
   const local=(()=>{try{return JSON.parse(localStorage.getItem('domino.me'))}catch(_){return null}})();
   setMe(Object.assign({name:'Tú',avatar:DomProfile.random(),coins:0,games:0,wins:0,prefs:PREFS},local||{}));document.getElementById('coins').textContent='—'}
  initLobby();lobbyEl.hidden=false;
  const sp=document.getElementById('splash');if(sp){sp.classList.add('hide');setTimeout(()=>sp.remove(),600)}
 })();
 if('serviceWorker'in navigator&&location.protocol==='https:')addEventListener('load',()=>navigator.serviceWorker.register('/sw.js').catch(()=>{}));
})();
