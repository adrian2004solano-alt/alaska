// Dominó Dominicano · panel de soporte (consultas, reportes, jugadores, chat)
(function(){
 const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
 const h=(t,a,...k)=>{const e=document.createElement(t);for(const x in a||{}){if(x==='class')e.className=a[x];else if(x.startsWith('on'))e.addEventListener(x.slice(2),a[x]);else if(a[x]!=null)e.setAttribute(x,a[x])}for(const c of k.flat())if(c!=null)e.append(c.nodeType?c:document.createTextNode(String(c)));return e};
 const when=t=>t?new Date(t).toLocaleString('es-DO'):'—';
 let KEY=sessionStorage.getItem('domino.admin')||'';
 const toast=(m,k)=>{const t=h('div',{class:'toast '+(k||'')},m);$('#toasts').append(t);setTimeout(()=>t.remove(),3500)};
 async function api(p,body){const r=await fetch(p,{method:body?'POST':'GET',headers:{'Content-Type':'application/json','X-Admin-Key':KEY},body:body?JSON.stringify(body):undefined});
  const d=await r.json().catch(()=>({}));if(!r.ok){if(r.status===401){sessionStorage.removeItem('domino.admin');location.reload()}throw new Error(d.error||'Error')}return d}
 $('#login').onsubmit=async e=>{e.preventDefault();KEY=$('#key').value;try{await api('/api/admin/stats');sessionStorage.setItem('domino.admin',KEY);start()}catch(err){toast(err.message,'bad')}};
 $('#out').onclick=()=>{sessionStorage.removeItem('domino.admin');location.reload()};
 $$('.atabs button').forEach(b=>b.onclick=()=>{$$('.atabs button').forEach(x=>x.classList.toggle('on',x===b));$$('#app section').forEach(s=>s.hidden=s.id!=='t-'+b.dataset.t);load(b.dataset.t)});
 async function start(){$('#login').hidden=true;$('#app').hidden=false;$('#out').hidden=false;kpis();load('tickets');setInterval(kpis,15000)}
 async function kpis(){const s=await api('/api/admin/stats');const box=$('#kpis');box.innerHTML='';
  for(const[v,l]of[[s.online,'en línea'],[s.playing,'jugando'],[s.users,'cuentas'],[s.matchesToday,'partidas hoy'],[s.openTickets,'consultas abiertas'],[s.openReports,'reportes']])box.append(h('div',{class:'stat'},h('b',{},v),h('span',{},l)))}
 function load(t){({tickets:loadTickets,reports:loadReports,users:loadUsers,chat:loadChat})[t]()}
 $('#tkFilter').onchange=loadTickets;
 async function loadTickets(){const r=await api('/api/admin/tickets'+($('#tkFilter').value?'?estado='+$('#tkFilter').value:''));const ul=$('#tkList');ul.innerHTML='';
  if(!r.items.length)ul.append(h('li',{class:'fine'},'No hay consultas.'));
  for(const t of r.items)ul.append(h('li',{},h('button',{onclick:()=>openTicket(t.id)},h('span',{},(t.unread_admin?'● ':'')+t.subject,h('br'),h('small',{class:'fine'},t.name+' · '+t.category+' · '+when(t.updated))),h('span',{class:'tag '+t.status},t.status))))}
 async function openTicket(id){const r=await api('/api/admin/tickets/'+id),v=$('#tkView');v.innerHTML='';const t=r.ticket;
  v.append(h('h2',{},t.subject),h('p',{class:'fine'},t.name+' (#'+t.uid+') · '+t.coins+' monedas · '+t.category));
  const th=h('div',{class:'thread'});for(const m of r.messages)th.append(h('div',{class:'bubble'+(m.admin?' admin':'')},h('small',{},(m.admin?'Soporte':t.name)+' · '+when(m.created)),m.text));v.append(th);
  const ta=h('textarea',{rows:4,placeholder:'Respuesta…'}),close=h('input',{type:'checkbox',style:'width:auto'});
  v.append(h('form',{class:'form',onsubmit:async e=>{e.preventDefault();try{await api('/api/admin/tickets/'+id+'/reply',{text:ta.value,close:close.checked});toast('Respuesta enviada','good');openTicket(id);loadTickets();kpis()}catch(err){toast(err.message,'bad')}}},
   ta,h('label',{style:'display:flex;gap:8px;align-items:center'},close,'Cerrar la consulta al responder'),h('div',{class:'row'},h('button',{class:'btn gold'},'Responder'),coinsBtn(t.uid,t.name))))}
 function coinsBtn(uid,name){return h('button',{type:'button',class:'btn ghost',onclick:()=>openCoins(uid,name,$('#tkView'))},'Ajustar monedas')}
 function openCoins(uid,name,v){const old=document.getElementById('coinsForm');if(old)old.remove();inp=h('input',{type:'number',id:'amt',placeholder:'ej. 100 o -50'}),rs=h('input',{placeholder:'Motivo'});
  v.append(h('form',{id:'coinsForm',class:'form inline',onsubmit:async e=>{e.preventDefault();try{const r=await api('/api/admin/users/'+uid+'/coins',{delta:+inp.value,reason:rs.value});toast(name+' ahora tiene '+r.coins+' monedas','good')}catch(err){toast(err.message,'bad')}}},h('label',{},'Monedas para '+name,inp),rs,h('button',{class:'btn gold'},'Aplicar')))}
 async function loadReports(){const r=await api('/api/admin/reports'),ul=$('#repList');ul.innerHTML='';if(!r.items.length)ul.append(h('li',{class:'fine'},'Sin reportes pendientes.'));
  for(const x of r.items)ul.append(h('li',{class:'card'},h('p',{},h('b',{},x.target||'?'),' escribió: "'+x.text+'"'),h('p',{class:'fine'},'Reportado por '+(x.reporter||'?')+' · '+when(x.created)),
   h('div',{class:'row'},h('button',{class:'btn ghost',onclick:async()=>{await api('/api/admin/chat/'+x.msg_id+'/delete',{});await api('/api/admin/reports/'+x.id+'/resolve',{});loadReports();kpis()}},'Borrar mensaje'),
    h('button',{class:'btn ghost',onclick:async()=>{await api('/api/admin/users/'+x.target_id+'/mute',{minutes:60});await api('/api/admin/reports/'+x.id+'/resolve',{});toast('Silenciado 1 hora','good');loadReports();kpis()}},'Silenciar 1 hora'),
    h('button',{class:'btn ghost',onclick:async()=>{await api('/api/admin/reports/'+x.id+'/resolve',{});loadReports();kpis()}},'Descartar'))))}
 $('#uSearch').onsubmit=e=>{e.preventDefault();loadUsers()};
 async function loadUsers(){const r=await api('/api/admin/users?q='+encodeURIComponent($('#uq').value||'')),tb=$('#uTable');tb.innerHTML='';
  tb.append(h('tr',{},...['#','Nombre','Monedas','Partidas','Ganadas','Última vez','Estado',''].map(x=>h('th',{},x))));
  for(const u of r.items){const muted=u.muted_until>Date.now();
   tb.append(h('tr',{},h('td',{},u.id),h('td',{},u.name+(u.registered?'':' (invitado)')),h('td',{},u.coins),h('td',{},u.games),h('td',{},u.wins),h('td',{},when(u.last_seen)),h('td',{},u.banned?'Suspendido':muted?'Silenciado':'Activo'),
    h('td',{},h('div',{class:'row',style:'margin:0'},
     h('button',{class:'btn ghost',onclick:()=>openCoins(u.id,u.name,$('#t-users'))},'Monedas'),
     h('button',{class:'btn ghost',onclick:async()=>{await api('/api/admin/users/'+u.id+'/mute',{minutes:muted?0:1440});loadUsers()}},muted?'Quitar silencio':'Silenciar 24 h'),
     h('button',{class:'btn ghost',onclick:async()=>{await api('/api/admin/users/'+u.id+'/ban',{ban:!u.banned,reason:'Incumplir las normas'});loadUsers()}},u.banned?'Reactivar':'Suspender')))))}}
 async function loadChat(){const r=await api('/api/admin/chat'),ul=$('#chatList');ul.innerHTML='';
  for(const m of r.items)ul.append(h('li',{class:'card'+(m.deleted?' del':'')},h('p',{},h('b',{},m.name+': '),m.text),h('p',{class:'fine'},when(m.created)+(m.deleted?' · borrado':'')),
   m.deleted?null:h('button',{class:'btn ghost',onclick:async()=>{await api('/api/admin/chat/'+m.id+'/delete',{});loadChat()}},'Borrar')))}
 if(KEY)api('/api/admin/stats').then(start).catch(()=>{});
})();
