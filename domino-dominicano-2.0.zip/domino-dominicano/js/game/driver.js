// Dominó Dominicano · game/driver.js
// Recibe los eventos del motor (del servidor en línea o de la mesa local en práctica) y los muestra en orden,
// esperando a que termine cada animación antes de pasar al siguiente.
// Nota: todos los archivos de js/core, js/game y js/render comparten el mismo ámbito global.
const EVQ=[];let ACT=()=>{},onMatchEnd=()=>{},practiceRoom=null,holdUntil=0,lastEnd=null;
function busy(){return chain.some(t=>t.anim)||!!knock||!!corrido||!!pendingEnd||!!endFx||now<holdUntil}
function pumpEvents(){
 let guard=0;
 while(EVQ.length&&guard++<20){
  const e=EVQ[0];
  if(e.type==='pick'||e.type==='pozo'||e.type==='draw'){if(phase==='shuffle'||endFx)return;if(e.type!=='pick'&&flights.length)return}
  else if(e.type==='end'){if(busy()||phase==='shuffle')return}
  else if(e.type!=='turn'&&e.type!=='seat'&&(busy()||flights.length))return;
  else if(e.type==='turn'&&(busy()||flights.length))return;
  EVQ.shift();handleEv(e)}}
function handleEv(e){
 switch(e.type){
 case'round':startShuffle(e.pos,e.round);scores=e.scores.slice();TARGETP=e.target;updScore();break;
 case'pick':{const d=deck[e.i];if(!d||d.taken)break;const s=seatOf(e.p);startPick(d,s,e.tile!=null?tileObj(e.tile):null);break}
 case'pozo':makePozo(e.idx);break;
 case'draw':drawFromPozo(seatOf(e.p),e.tile!=null?tileObj(e.tile):null);holdUntil=now+260;break;
 case'start':phase='play';deck=deck.filter(d=>d.pozo&&!d.taken);
  {const s=seatOf(e.starter);toast={t0:now,txt:(s===0?'Sales tú':'Sale '+seatName(s))+(e.must!=null?' con el '+DomEngine.tileOf(e.must).join('|'):''),ok:true}}break;
 case'turn':{turn=seatOf(e.p);turnT0=now;turnDur=e.ms||rnd2(1000,1800);sel=-1;
  if(turn===0){legalNow=e.legal||[];passBtn=legalNow.length?null:{t0:now,ms:e.ms||6000}}else{legalNow=[];passBtn=null}break}
 case'play':{const s=seatOf(e.p),t=tileObj(e.tile);let from;
  if(s===0){const it=H.find(i=>i.t.id===e.tile);from=it?fromItem(it):{x:0,y:BH+60,a:0}}else from=seatFrom(s);
  playVisual(s,t,slotFor(t,e.end),from);break}
 case'pass':{const s=seatOf(e.p);passVisual(s);if(e.bonus)giveBonus(seatOf(e.bonus.giver),s,e.bonus.pts,'pase',e.scores);break}
 case'corrido':{const s=seatOf(e.p);corrido={p:s,t0:now+120,i:0,tranque:!!e.tranque,pts:e.pts,scores:e.scores};break}
 case'roundEnd':{const r=e;pendingEnd={at:now+(r.cap?700:1000),kind:r.kind,winner:r.winner>=0?seatOf(r.winner):-1,cap:r.cap,nums:r.nums,res:r};
  if(!r.cap)scores=r.scores.slice();break}
 case'seat':if(SEATS[seatOf(e.seat)])Object.assign(SEATS[seatOf(e.seat)],{connected:e.connected,left:e.left});break;
 case'end':lastEnd=e.info;onMatchEnd(e.info);break}}
// mensajes de la mesa (servidor o práctica)
function tableMsg(m){
 if(m.t==='ev')EVQ.push(...m.e);
 else if(m.t==='seat')EVQ.push({type:'seat',seat:m.seat,connected:m.connected,left:m.left});
 else if(m.t==='end')EVQ.push({type:'end',info:m.info});
 else if(m.t==='reject'){for(const it of H)it.pending=null;toast={t0:now,txt:m.msg}}
 else if(m.t==='tchat')tableChat(m)}
// entrar a una mesa: seats = [{name,avatar,bot}] por jugador del motor; me = mi índice en el motor
function enterTable(info){
 MODE=info.mode;NSEAT=DomEngine.MODES[MODE].n;ME=info.me;STAKE=info.stake||0;ONLINE=!!info.online;DEAL=7;TARGETP=DomEngine.MODES[MODE].target;
 SEATS=[];info.seats.forEach((p,i)=>{SEATS[seatOf(i)]=Object.assign({},p)});
 EVQ.length=0;deck=[];resetTable();scores=[0,0];round=0;lastEnd=null;phase='idle';STATIC=null;for(const k in RCACHE)delete RCACHE[k];
 chatLog=[];updScore();
 if(info.view)restoreView(info.view)}
// volver a dibujar una mesa a medias (al reconectarse)
function restoreView(v){
 scores=v.scores.slice();round=v.round;TARGETP=v.target;
 deck=v.pos.map((q,i)=>({i,x:q.x,y:q.y,a:q.a,tx:q.x,ty:q.y,ta:q.a,taken:v.deck[i]>=0&&v.deck[i]!==99}));
 v.counts.forEach((n,p)=>{const s=seatOf(p);shown[s]=n;got[s]=n});
 H=v.hand.map((id,i)=>({t:tileObj(id),x:CX+(i-(v.hand.length-1)/2)*STEP,y:HY,ang:Math.PI/2,sc:1}));
 if(v.phase==='pick'){phase=v.pickOpenIn>0?'shuffle':'pick';targetPos=v.pos;ph0=now-Math.max(0,2800-v.pickOpenIn+1000);if(phase==='pick')pickOpen=now;return}
 const pz=v.deck.map((o,i)=>o===99?i:-1).filter(i=>i>=0);
 deck=deck.filter((d,i)=>pz.includes(i));deck.forEach(d=>d.taken=false);makePozo(deck.map(d=>d.i));deck.forEach(d=>{d.x=d.tx;d.y=d.ty;d.a=d.ta});
 // la cola se rehace jugada por jugada (la colocación es siempre la misma)
 for(const cp of v.chain){const t=tileObj(cp.tile);playVisual(seatOf(cp.p),t,slotFor(t,cp.end),null);shown[seatOf(cp.p)]++}
 v.counts.forEach((n,p)=>{const s=seatOf(p);if(s)shown[s]=n});
 H=v.hand.map((id,i)=>({t:tileObj(id),x:CX+(i-(v.hand.length-1)/2)*STEP,y:HY,ang:Math.PI/2,sc:1}));
 phase=v.phase==='play'?'play':'roundEnd';
 if(v.turn>=0)handleEv({type:'turn',p:v.turn,legal:v.legal,ms:v.deadlineIn||25000});updScore()}
// ---- modo práctica: la misma mesa del servidor, pero corriendo en tu navegador contra la computadora ----
function startPractice(mode,me){
 if(practiceRoom)practiceRoom.destroy();
 const n=DomEngine.MODES[mode].n,names=['Ramón','Mayra','Felo','Yohanna'].sort(()=>Math.random()-.5);
 const players=[];for(let i=0;i<n;i++)players.push(i===0?{name:me.name||'Tú',avatar:me.avatar,bot:false}:{name:names[i],avatar:DomProfile.random(),bot:true});
 practiceRoom=new DomRoom({mode,players,send:(seat,msg)=>{if(seat===0)setTimeout(()=>tableMsg(JSON.parse(JSON.stringify(msg))),0)}});
 ACT=a=>{const err=practiceRoom.action(0,a);if(err)tableMsg({t:'reject',msg:err})};
 enterTable({mode,me:0,seats:practiceRoom.info(),stake:0,online:false});
 practiceRoom.start()}
function stopPractice(){if(practiceRoom){practiceRoom.destroy();practiceRoom=null}}
