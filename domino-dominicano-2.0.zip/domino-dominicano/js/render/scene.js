// Dominó Dominicano · render/scene.js
// Dibujo por cuadro: fichas de la mesa, fantasmas de jugada, reparto, mano, letreros y bucle principal.
// Nota: todos los archivos de js/core, js/game y js/render comparten el mismo ámbito global y se cargan en el orden
// definido en js/app/loader.js (no cambies ese orden sin probar).
// ---- ficha de tablero: cada vértice se proyecta con la perspectiva exacta, así las fichas vecinas comparten
// los mismos puntos en pantalla y quedan perfectamente pegadas (antes se aproximaba cada ficha con una transformación afín).
const TPOLY=(()=>{const pts=[],hl=L/2,hw=W/2,r=W*.12;
 for(const[cx,cy,a0]of[[hl-r,-hw+r,-Math.PI/2],[hl-r,hw-r,0],[-hl+r,hw-r,Math.PI/2],[-hl+r,-hw+r,Math.PI]])
  for(let i=0;i<=3;i++){const a=a0+i*Math.PI/6;pts.push([cx+Math.cos(a)*r,cy+Math.sin(a)*r])}
 return pts})();
// pass: 0 sombra en la mesa, 1 canto (grosor), 2 cara
function tileB(x,y,a,t,lift,sc,hl,al,pass){
 const co=Math.cos(a),si=Math.sin(a),Pc=proj(x,y);
 const pr=(u,v)=>{const P=proj(x+u*co-v*si,y+u*si+v*co);return{x:Pc.x+(P.x-Pc.x)*sc,y:Pc.y+(P.y-Pc.y)*sc-lift}};
 const path=(dy,dx)=>{c.beginPath();TPOLY.forEach(([u,v],i)=>{const p=pr(u,v);i?c.lineTo(p.x+dx,p.y+dy):c.moveTo(p.x+dx,p.y+dy)});c.closePath()};
 c.globalAlpha=al;
 if(pass===0){path(lift+5,5);c.fillStyle='#00000040';c.fill()}
 else if(pass===1){const th=3.4*Pc.s*sc;path(th,0);c.fillStyle=TH.edge;c.fill();c.lineWidth=1;c.strokeStyle=TH.edgeStroke;c.stroke()}
 else{
  path(0,0);const g0=pr(0,-W/2),g1=pr(0,W/2),g=c.createLinearGradient(g0.x,g0.y,g1.x,g1.y);
  g.addColorStop(0,TH.face[0]);g.addColorStop(1,TH.face[2]);c.fillStyle=g;c.fill();
  {const e1=pr(1,0),e0=pr(0,0);c.save();c.globalAlpha=.42*TH.tex;c.fillStyle=texAt(IVORY,Math.atan2(e1.y-e0.y,e1.x-e0.x)+Math.PI/2,.16*Pc.s*sc,e0.x,e0.y);c.fill();c.restore()}
  c.lineWidth=.9;c.strokeStyle=TH.stroke;c.stroke();
  if(hl){c.lineWidth=3.5;c.strokeStyle=hl;c.stroke()}
  const d0=pr(0,-W*.4),d1=pr(0,W*.4);c.beginPath();c.moveTo(d0.x,d0.y);c.lineTo(d1.x,d1.y);c.strokeStyle=TH.line;c.lineWidth=1.6;c.stroke();
  const gg=W*.25;
  for(const[p,cu]of[[t.p1,-L/4],[t.p2,L/4]]){c.fillStyle=pipColor(p);for(const[px,py]of(PIP[p]||[])){
   const u=cu+px*gg,v=py*gg,P=pr(u,v),Ex=pr(u+1,v),Ey=pr(u,v+1);
   c.save();c.translate(P.x,P.y);c.transform(Ex.x-P.x,Ex.y-P.y,Ey.x-P.x,Ey.y-P.y,0,0);c.beginPath();c.arc(0,0,W*.088,0,7);c.fill();c.restore()}}
  const pc=pr(0,0);c.beginPath();c.arc(pc.x,pc.y,1.7,0,7);c.fillStyle='#c9a227';c.fill()}
 c.globalAlpha=1}
// golpe de capicúa: sube la ficha del extremo y cae con fuerza
function capLift(side){if(!capFx||!side)return 0;let m=0;
 for(const h of capFx.hits){if(h.n!==side&&h.n!=='B')continue;const ag=now-h.t;if(ag<0)continue;let l=0;
  if(ag<CAPR*.7){l=40*ease(ag/(CAPR*.7))}
  else if(ag<CAPR){const f=(ag-CAPR*.7)/(CAPR*.3);l=40*(1-f*f)}
  else if(ag<CAPR+170)l=9*Math.sin(Math.PI*(ag-CAPR)/170);
  m=Math.max(m,l)}
 return m}
// Al caer una ficha, la mesa se sacude: la ficha rebota y las vecinas se empujan y vibran un momento; cada golpe
// deja un pequeño desorden permanente (solo visual: la lógica de colocación no cambia).
const clp=(v,m)=>Math.max(-m,Math.min(m,v));
// Al caer una ficha, la mesa se sacude un poco: la ficha rebota y las vecinas se empujan y vibran un momento; cada golpe
// deja un pequeño desorden permanente (solo visual: la lógica de colocación no cambia).
let shakes=[];
function impact(T){const R=Math.random;
 for(const u of chain){const dx=u.x-T.x,dy=u.y-T.y,d=Math.hypot(dx,dy);
  if(u===T){u.wb={t0:now,dx:(R()-.5)*8,dy:(R()-.5)*5,da:(R()-.5)*.3};u.jx=clp((u.jx||0)+(R()-.5)*2.4,2.6);u.jy=clp((u.jy||0)+(R()-.5)*1.8,2);u.ja=clp((u.ja||0)+(R()-.5)*.05,.03);continue}
  if(d>190)continue;const am=1-d/190,l=d||1;
  u.wb={t0:now,dx:dx/l*6*am,dy:dy/l*4.5*am,da:(R()-.5)*.3*am};
  u.jx=clp((u.jx||0)+dx/l*.5*am+(R()-.5)*.5*am,2.6);u.jy=clp((u.jy||0)+dy/l*.4*am+(R()-.5)*.4*am,2);u.ja=clp((u.ja||0)+(R()-.5)*.04*am,.03)}}
function drawBoard(){
 T2();const items=[];
 for(const t of chain){let x=t.x,y=t.y,a=t.ang,lift=0,sc=1;
  if(t.anim){const u=clamp((now-t.anim.t0)/t.anim.dur),e=ease(u);x=lerp(t.anim.fx,t.x,e);y=lerp(t.anim.fy,t.y,e);a=t.anim.fa+angd(t.anim.fa,t.ang)*e;lift=Math.sin(Math.PI*u)*26;sc=1+.18*(1-u)}
  else if(t.bump&&now-t.bump<150)lift=3*Math.sin(Math.PI*(now-t.bump)/150);
  lift+=capLift(ends.L&&t===ends.L.tile?'L':ends.R&&t===ends.R.tile?'R':null);
  if(t.mv){const u=clamp((now-t.mv.t0)/450);if(u>=1)t.mv=null;else{const e=ease(u);x=lerp(t.mv.fx,x,e);y=lerp(t.mv.fy,y,e);a=t.mv.fa+angd(t.mv.fa,a)*e}}
  let jx=t.jx||0,jy=t.jy||0,ja=t.ja||0;
  if(t.wb){const ag=now-t.wb.t0;if(ag>1100)t.wb=null;else if(ag>=0){const f=Math.exp(-ag/170)*Math.cos(ag/42);jx+=t.wb.dx*f;jy+=t.wb.dy*f;ja+=t.wb.da*f}}
  items.push({t,x:x+jx,y:y+jy,a:a+ja,lift,sc})}
 items.sort((p,q)=>p.lift-q.lift);
 for(const i of items)if(i.lift>2)tileB(i.x,i.y,i.a,i.t,i.lift,i.sc,null,1,0);
 for(const i of items)tileB(i.x,i.y,i.a,i.t,i.lift,i.sc,null,1,1);
 for(const i of items)tileB(i.x,i.y,i.a,i.t,i.lift,i.sc,null,1,2);
 // ondas del golpe de capicúa
 if(capFx)for(const h of capFx.hits){const ag=now-h.t-CAPR;if(ag<0||ag>800)continue;
  for(const n of(h.n==='B'?['L','R']:[h.n])){const tl=ends[n]&&ends[n].tile;if(!tl)continue;
   TB(tl.x,tl.y,0);
   const fl=clamp(1-ag/220);if(fl>0){const g=c.createRadialGradient(0,0,0,0,0,70);g.addColorStop(0,'rgba(255,230,140,'+.7*fl+')');g.addColorStop(1,'rgba(255,200,60,0)');c.fillStyle=g;c.beginPath();c.arc(0,0,70,0,7);c.fill()}
   for(let r=0;r<2;r++){const u=clamp((ag-r*110)/620);if(u<=0||u>=1)continue;
    c.beginPath();c.arc(0,0,24+u*130,0,7);c.lineWidth=7*(1-u)+1;c.strokeStyle='rgba(255,215,90,'+(1-u)*.9+')';c.stroke()}}}
 // ficha de un rival que sale a golpear la mesa al pasar
 if(knock&&knock.p!==0){const s=knockSt(),p=knock.p,base=seatFrom(p),inn=p===2?{x:0,y:46,a:Math.PI/2}:p===1?{x:BW/2-48,y:BH/2,a:0}:{x:-BW/2+48,y:BH/2,a:0};
  const bx=p===2?0:base.x,by=p===2?-60:BH/2;
  const x=lerp(bx,inn.x,s.out),y=lerp(by,inn.y,s.out);
  TB(x+4,y+5,inn.a,0);c.globalAlpha=.22*s.out;rr(-L/2,-W/2,L,W,4);c.fillStyle='#000';c.fill();c.globalAlpha=1;
  TB(x,y,inn.a,34*s.arc);tile(L,W,0,0,false)}}
function drawGhosts(){
 const it=drag?drag.it:(sel>=0?H[sel]:null);if(!it||!canAct())return;
 const ss=slots(it.t),n=drag?nearest(it.t,ptr):{s:null};
 T2();
 for(const s of ss){const near=drag&&n.s===s&&n.d<180,pu=.5+.5*Math.sin(now/180),al=near?.8:.3+.25*pu;
  tileB(s.pl.x,s.pl.y,s.pl.ang,s.pl,0,1,'#ffc933',al,1);tileB(s.pl.x,s.pl.y,s.pl.ang,s.pl,0,1,'#ffc933',al,2)}}
function drawDeck(){
 const free=deck.filter(d=>!d.taken&&!d.pozo).length,mine=phase==='pick'&&now>=pickOpen&&got[0]<DEAL&&free<=DEAL-got[0];
 const glow='rgba(255,201,51,'+(.55+.45*Math.sin(now/170))+')';
 for(const d of deck){if(d.taken)continue;const hv=hoverDeck===d&&phase==='pick',lift=hv?8:(phase==='shuffle'?10:0);
  TB(d.x+3,d.y+4,d.a,0);c.globalAlpha=.32;rr(-L/2,-W/2,L,W,W*.16);c.fillStyle='#000';c.fill();c.globalAlpha=1;
  let lf=lift,face=false,sy=1;
  if(d.hopT){const ag=now-d.hopT;if(ag>=0&&ag<520)lf+=d.hop*Math.sin(Math.PI*ag/520)}
  if(d.face){if(!d.flip||now<d.flip)face=true;else{const u=clamp((now-d.flip)/320);sy=Math.max(.06,Math.abs(Math.cos(Math.PI*u)));face=u<.5;lf+=12*Math.sin(Math.PI*u);if(u>=1){d.face=false;d.flip=0}}}
  if(d.lift)lf+=d.lift;if(d.pending&&!d.taken)lf+=6;
  TB(d.x,d.y,d.a,lf);if(sy<1)c.transform(1,0,0,sy,0,0);tile(L,W,d.t?d.t.a:0,d.t?d.t.b:0,face&&!!d.t,hv?'#ffc933':mine?glow:null)}}
function drawHand(){
 const standing=it=>!(drag&&drag.it===it)&&Math.abs(angd(it.ang,Math.PI/2))<.08&&Math.abs(it.sc-1)<.1;
 T2();for(const it of H)if(standing(it))handTile(it.x,it.y,it.sc,it.t);
 rackLip();
 const order=H.map((it,i)=>i).filter(i=>!standing(H[i])).sort((a,b)=>(drag&&drag.it===H[a]?1:0)-(drag&&drag.it===H[b]?1:0));
 for(const i of order){const it=H[i],dr=drag&&drag.it===it;
  if(dr){TS(it.x+8,it.y+14,it.ang,it.sc);c.globalAlpha=.25;rr(-HL/2,-HW/2,HL,HW,6);c.fillStyle='#000';c.fill();c.globalAlpha=1}
  TS(it.x,it.y,it.ang,it.sc);tile(HL,HW,it.t.a,it.t.b,true)}
 for(const f of flights){const u=clamp((now-f.t0)/f.dur),e=ease(u),x=lerp(f.x0,f.to.x,e),y=lerp(f.y0,f.to.y,e)-Math.sin(Math.PI*u)*50,a=f.a0+angd(f.a0,f.to.a)*e,sc=lerp(f.sc0,f.to.sc,e);
  TS(x,y,a,sc);tile(HL,HW,f.t?f.t.a:0,f.t?f.t.b:0,f.seat===0&&u>.5&&!!f.t)}}
function drawBonuses(){
 const pos=[[CX,430],[1110,300],[CX,165],[450,300]];
 for(const b of bonuses){const u=now-b.t0;if(u<0||u>1500)continue;
  const[x0,y0]=pos[b.giver]||pos[0];let x=x0,y=y0-Math.min(u,700)*.05,sc,al=1;
  if(u<700){const q=u/260;sc=u<260?1+2.7*Math.pow(q-1,3)+1.7*Math.pow(q-1,2):1+.03*Math.sin(u/60)}
  else{const f=ease((u-700)/800);x=lerp(x0,b.tx,f);y=lerp(y0-35,b.ty,f);sc=lerp(1,.35,f);al=clamp((1500-u)/300)}
  // chispas
  if(u<900){for(let i=0;i<10;i++){const a=i/10*6.283+b.seed,r=(u/900)*(70+i%3*25),px=x0+Math.cos(a)*r,py=y0-35+Math.sin(a)*r*.7-u*.03;
   c.globalAlpha=clamp(1-u/900);c.beginPath();c.arc(px,py,5-(u/900)*3,0,7);c.fillStyle=i%2?'#ffd34d':'#fff2a8';c.fill()}c.globalAlpha=1}
  c.save();c.globalAlpha=al;c.translate(x,y);c.scale(sc,sc);c.rotate(-.04);
  c.font='900 84px Georgia,serif';c.textAlign='center';c.textBaseline='middle';c.lineJoin='round';
  c.shadowColor='#000a';c.shadowBlur=18;c.lineWidth=14;c.strokeStyle='#4a1d00';c.strokeText('+'+b.pts,0,0);c.shadowBlur=0;
  const g=c.createLinearGradient(0,-40,0,40);g.addColorStop(0,'#fff6b0');g.addColorStop(.5,'#ffc51f');g.addColorStop(1,'#d97706');c.fillStyle=g;c.fillText('+'+b.pts,0,0);
  if(u<700&&b.kind!=='corrido')pill(0,58,(b.passer===0?'¡Pasaste!':'¡'+seatName(b.passer)+' pasó!')+' · +'+b.pts+' para '+teamLabel(b.mine),'bold 20px system-ui','#222d','#ffd34d',36);
  c.restore();c.globalAlpha=1}}
function drawUI(){
 T2();drawBonuses();
 if(capFx){const u=now-capFx.c0;if(u>=0&&u<CAPD){
  const bk=x=>1+2.70158*Math.pow(x-1,3)+1.70158*Math.pow(x-1,2),s=u<380?bk(u/380):1+.025*Math.sin(u/90),al=clamp((CAPD-u)/450);
  c.save();c.globalAlpha=al;c.translate(CX,300);c.scale(s,s);c.rotate(-.05);
  c.font='900 96px Georgia,serif';c.textAlign='center';c.textBaseline='middle';c.lineJoin='round';
  c.shadowColor='#000a';c.shadowBlur=24;c.lineWidth=16;c.strokeStyle='#4a1d00';c.strokeText('¡CAPICÚA!',0,0);c.shadowBlur=0;
  const g=c.createLinearGradient(0,-48,0,48);g.addColorStop(0,'#fff6b0');g.addColorStop(.5,'#ffc51f');g.addColorStop(1,'#d97706');c.fillStyle=g;c.fillText('¡CAPICÚA!',0,0);
  const n=capFx.nums;pill(0,76,(capFx.w===0?'Ganas':seatName(capFx.w)+' gana')+' por los dos lados'+(n?' · '+n[0]+' | '+n[1]:''),'bold 24px system-ui','#222d','#ffd34d',44);
  c.restore();c.globalAlpha=1}}
 if(corridoFx){const u=now-corridoFx.t0,D=1900;if(u>=0&&u<D){
  const bk=x=>1+2.70158*Math.pow(x-1,3)+1.70158*Math.pow(x-1,2),sc=u<340?bk(u/340):1+.02*Math.sin(u/80),al=clamp((D-u)/380);
  c.save();c.globalAlpha=al;c.translate(CX,250);c.scale(sc*.85,sc*.85);c.rotate(-.04);
  c.font='900 92px Georgia,serif';c.textAlign='center';c.textBaseline='middle';c.lineJoin='round';
  c.shadowColor='#000a';c.shadowBlur=24;c.lineWidth=16;c.strokeStyle='#4a1d00';c.strokeText('¡PASE CORRIDO!',0,0);c.shadowBlur=0;
  const g=c.createLinearGradient(0,-46,0,46);g.addColorStop(0,'#fff6b0');g.addColorStop(.5,'#ffc51f');g.addColorStop(1,'#d97706');c.fillStyle=g;c.fillText('¡PASE CORRIDO!',0,0);
  const w=corridoFx.p;pill(0,78,'Nadie lleva · +'+CORRIDO_PTS+' para '+teamLabel(seatIsMine(w))+' · vuelve a jugar '+(w===0?'tú':seatName(w)),'bold 24px system-ui','#222d','#ffd34d',44);
  c.restore();c.globalAlpha=1}else if(u>=D)corridoFx=null}
 if(phase==='play'&&turn===0&&!pendingEnd&&!passBtn&&!drag&&!knock&&!corrido)pill(CX,490,'Te toca','bold 17px system-ui','#40372ae6','#fff',30);
 if(phase==='pick'&&now>=pickOpen&&got[0]<DEAL)pill(CX,490,'Toca las fichas de la mesa para tomarlas ('+got[0]+'/'+DEAL+')','bold 17px system-ui','#222e','#fff',30);
 if(phase==='pick'&&got[0]>=DEAL)pill(CX,490,'Esperando a los demás…','bold 16px system-ui','#222e','#fff',30);
 if(endMsg&&now-endMsg.t0<4200)pill(CX,270,endMsg.txt,'bold 20px system-ui','#222e','#ffd34d',40,clamp((4200-(now-endMsg.t0))/400));
 if(phase==='shuffle')pill(CX,330,'Barajando las fichas…','bold 18px system-ui','#222d','#fff',34);
 if(passBtn&&!knock&&turn===0){const f=clamp(1-(now-passBtn.t0)/(passBtn.ms||6000));pill(CX,490,'No tienes ficha: pulsa PASO','bold 15px system-ui','#40372ae6','#fff',28);
  c.beginPath();c.arc(PB.x,PB.y,PB.r,0,7);c.fillStyle='#262626';c.fill();c.lineWidth=8;c.strokeStyle='#ffffff55';c.stroke();
  c.beginPath();c.arc(PB.x,PB.y,PB.r,-Math.PI/2,-Math.PI/2+Math.PI*2*f);c.strokeStyle='#e63a2e';c.stroke();
  c.fillStyle='#fff';c.font='bold 18px system-ui';c.textAlign='center';c.textBaseline='middle';c.fillText('PASO',PB.x,PB.y+1)}
 const pos=[[CX,430],[1110,300],[CX,165],[450,300]];
 for(const bb of bubbles){const u=clamp((now-bb.t0)/160),[x,y]=pos[bb.p],e=ease(u),al=clamp((1800-(now-bb.t0))/300);
  c.save();c.translate(x,y);c.scale(.6+.4*e,.6+.4*e);c.translate(-x,-y);c.globalAlpha=al;
  c.font='bold 26px system-ui';const w=c.measureText('Paso').width+34;rr(x-w/2,y-24,w,48,12);c.fillStyle='#222d';c.fill();
  c.beginPath();if(bb.p===0||bb.p===2){const sg=bb.p===0?1:-1;c.moveTo(x-9,y+24*sg);c.lineTo(x+9,y+24*sg);c.lineTo(x,y+36*sg)}c.fill();
  c.fillStyle='#fff';c.textAlign='center';c.textBaseline='middle';c.fillText('Paso',x,y+1);c.restore()}
 if(toast&&now-toast.t0<2200)pill(CX,440,toast.txt,'15px system-ui',toast.ok?'#222e':'#7a1f1fe6','#fff',30,clamp((2200-(now-toast.t0))/400));
 drawChatBubbles()}
let LOOP=false;
function frame(t){if(!LOOP)return;now=t;update();scene();drawBoard();drawGhosts();drawDeck();drawHand();drawUI();requestAnimationFrame(frame)}
function startLoop(){if(!LOOP){LOOP=true;requestAnimationFrame(frame)}}
function stopLoop(){LOOP=false}
