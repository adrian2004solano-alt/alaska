// Dominó Dominicano · moderación del chat
// Tapa groserías, quita enlaces (spam) y limita cuántos mensajes se pueden mandar seguido.
// La lista se puede ampliar: agrega palabras en minúscula y sin acentos.
const BAD = [
  'mierda', 'coño', 'cono', 'carajo', 'puta', 'puto', 'putas', 'putos', 'hijueputa', 'hdp', 'pendejo', 'pendeja', 'pendejos',
  'maricon', 'maricona', 'mariconazo', 'cabron', 'cabrona', 'mamaguevo', 'mamaguebo', 'mmg', 'singao', 'singada', 'singar',
  'verga', 'guevo', 'huevon', 'malparido', 'malparida', 'culo', 'culero', 'toto', 'chupamela', 'mamahuevo', 'gonorrea',
  'zorra', 'perra', 'idiota', 'imbecil', 'estupido', 'estupida', 'retrasado', 'subnormal', 'fuck', 'shit', 'bitch', 'asshole', 'motherfucker'
];
const norm = (s) => s.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[0@]/g, 'o').replace(/[1!]/g, 'i').replace(/3/g, 'e').replace(/4/g, 'a').replace(/\$/g, 's');
const BAD_RE = new RegExp('\\b(' + BAD.map((w) => norm(w).replace(/(.)/g, '$1+')).join('|') + ')\\b', 'gi');

export function hasBad(text) { BAD_RE.lastIndex = 0; return BAD_RE.test(norm(text)); }

// Limpia un mensaje: sin caracteres de control, sin enlaces, groserías tapadas
export function clean(text, max) {
  let t = String(text || '').replace(/[\u0000-\u001f\u007f​-‏‪-‮]/g, ' ').replace(/\s+/g, ' ').trim();
  if (max) t = t.slice(0, max);
  t = t.replace(/\b(?:https?:\/\/|www\.)\S+/gi, '[enlace]').replace(/\b\S+\.(?:com|net|org|do|io|co|me|xyz|ly)(?:\/\S*)?\b/gi, '[enlace]');
  // tapar groserías respetando el largo de cada palabra
  const words = t.split(/(\s+)/);
  return words.map((w) => { BAD_RE.lastIndex = 0; return BAD_RE.test(norm(w)) ? w[0] + '*'.repeat(Math.max(2, w.length - 1)) : w; }).join('');
}

// Límite de mensajes: n mensajes cada ms milisegundos
export function limiter(n, ms) {
  const hits = new Map();
  return (key) => {
    const t = Date.now(), arr = (hits.get(key) || []).filter((x) => t - x < ms);
    if (arr.length >= n) { hits.set(key, arr); return false; }
    arr.push(t); hits.set(key, arr);
    if (hits.size > 5000) for (const [k, v] of hits) if (!v.length || t - v[v.length - 1] > ms) hits.delete(k);
    return true;
  };
}
