// Dominó Dominicano · API (cuentas, bonos, ranking, soporte y administración)
import { timingSafeEqual, createHash } from 'node:crypto';
import { q, now, moveCoins, tx } from './db.js';
import { CFG } from './config.js';
import { clean, limiter } from './moderation.js';
import * as U from './users.js';

const authLimit = limiter(10, 60000), guestLimit = limiter(CFG.GUEST_PER_HOUR, 3600000), ticketLimit = limiter(6, 3600000), msgLimit = limiter(20, 3600000), adminLimit = limiter(30, 60000);
const CATS = ['Cuenta', 'Monedas', 'Partida', 'Reportar a un jugador', 'Sugerencia', 'Otro'];

export function makeApi(hub) {
  const routes = [];
  const on = (method, path, fn, opts = {}) => routes.push({ method, re: new RegExp('^' + path.replace(/:(\w+)/g, '(?<$1>[^/]+)') + '$'), fn, opts });

  // ---- cuentas ----
  on('POST', '/api/guest', (c) => {
    if (!guestLimit(c.ip)) return [429, { error: 'Demasiadas cuentas nuevas desde tu conexión. Intenta más tarde.' }];
    const u = U.createGuest();
    return { token: U.newSession(u.id), me: U.publicMe(u) };
  });
  on('POST', '/api/login', (c) => {
    if (!authLimit(c.ip)) return [429, { error: 'Demasiados intentos. Espera un minuto.' }];
    const r = U.login(c.body.name, c.body.password);
    if (r.error) return [400, r];
    return { token: r.token, me: U.publicMe(r.user) };
  });
  on('POST', '/api/register', (c) => {
    if (!authLimit(c.ip)) return [429, { error: 'Demasiados intentos. Espera un minuto.' }];
    if (c.user.registered) return [400, { error: 'Tu cuenta ya tiene contraseña.' }];
    const r = U.register(c.user, c.body.name, c.body.password);
    if (r.error) return [400, r];
    hub.notify(c.user.id, { t: 'me', me: U.publicMe(r.user) });
    return { me: U.publicMe(r.user) };
  }, { auth: true });
  on('POST', '/api/logout', (c) => { U.endSession(c.token); return { ok: true }; }, { auth: true });
  on('GET', '/api/me', (c) => ({ me: U.publicMe(c.user) }), { auth: true });
  on('POST', '/api/profile', (c) => {
    const r = U.updateProfile(c.user, c.body || {});
    if (r.error) return [400, r];
    hub.notify(c.user.id, { t: 'me', me: U.publicMe(r.user) });
    return { me: U.publicMe(r.user) };
  }, { auth: true });

  // ---- monedas ----
  on('POST', '/api/daily', (c) => { const r = U.claimDaily(c.user); if (r.error) return [400, r]; hub.notify(c.user.id, { t: 'coins', coins: r.coins, delta: r.amount, reason: 'bono diario' }); return r; }, { auth: true });
  on('POST', '/api/rescue', (c) => { const r = U.claimRescue(c.user); if (r.error) return [400, r]; hub.notify(c.user.id, { t: 'coins', coins: r.coins, delta: r.amount, reason: 'bono de rescate' }); return r; }, { auth: true });
  on('GET', '/api/history', (c) => ({ items: U.history(c.user) }), { auth: true });
  on('GET', '/api/leaderboard', () => ({ items: U.leaderboard() }));
  on('GET', '/api/health', () => ({ ok: true, ...hub.stats() }));

  // ---- servicio al cliente ----
  const ticketOut = (t) => ({ id: t.id, category: t.category, subject: t.subject, status: t.status, unread: !!t.unread_user, created: t.created, updated: t.updated });
  on('GET', '/api/tickets', (c) => ({ items: q('SELECT * FROM tickets WHERE user_id = ? ORDER BY updated DESC LIMIT 50').all(c.user.id).map(ticketOut) }), { auth: true });
  on('POST', '/api/tickets', (c) => {
    if (!ticketLimit(c.user.id)) return [429, { error: 'Ya enviaste varias consultas. Te responderemos pronto.' }];
    const cat = CATS.includes(c.body.category) ? c.body.category : 'Otro';
    const subject = clean(c.body.subject, 80), text = clean(c.body.text, 2000);
    if (subject.length < 3 || text.length < 5) return [400, { error: 'Escribe un asunto y cuéntanos qué pasó.' }];
    const id = tx(() => {
      const r = q('INSERT INTO tickets (user_id, category, subject, created, updated) VALUES (?, ?, ?, ?, ?)').run(c.user.id, cat, subject, now(), now());
      const id = Number(r.lastInsertRowid);
      q('INSERT INTO ticket_msgs (ticket_id, text, created) VALUES (?, ?, ?)').run(id, text, now());
      return id;
    });
    return { id };
  }, { auth: true });
  on('GET', '/api/tickets/:id', (c) => {
    const t = q('SELECT * FROM tickets WHERE id = ? AND user_id = ?').get(+c.params.id, c.user.id);
    if (!t) return [404, { error: 'No encontramos esa consulta.' }];
    q('UPDATE tickets SET unread_user = 0 WHERE id = ?').run(t.id);
    return { ticket: ticketOut(t), messages: q('SELECT from_admin AS admin, text, created FROM ticket_msgs WHERE ticket_id = ? ORDER BY id').all(t.id) };
  }, { auth: true });
  on('POST', '/api/tickets/:id/messages', (c) => {
    const t = q('SELECT * FROM tickets WHERE id = ? AND user_id = ?').get(+c.params.id, c.user.id);
    if (!t) return [404, { error: 'No encontramos esa consulta.' }];
    if (!msgLimit(c.user.id)) return [429, { error: 'Más despacio, por favor.' }];
    const text = clean(c.body.text, 2000); if (text.length < 2) return [400, { error: 'Escribe tu mensaje.' }];
    q('INSERT INTO ticket_msgs (ticket_id, text, created) VALUES (?, ?, ?)').run(t.id, text, now());
    q("UPDATE tickets SET status = 'abierto', unread_admin = 1, updated = ? WHERE id = ?").run(now(), t.id);
    return { ok: true };
  }, { auth: true });

  // ---- administración (requiere ADMIN_KEY) ----
  const A = (fn) => (c) => fn(c);
  on('GET', '/api/admin/stats', A(() => ({
    ...hub.stats(),
    users: q('SELECT COUNT(*) n FROM users').get().n, registered: q('SELECT COUNT(*) n FROM users WHERE registered = 1').get().n,
    matchesToday: q('SELECT COUNT(*) n FROM matches WHERE created > ?').get(now() - 86400e3).n,
    openTickets: q("SELECT COUNT(*) n FROM tickets WHERE status = 'abierto'").get().n,
    openReports: q('SELECT COUNT(*) n FROM reports WHERE resolved = 0').get().n,
    coins: q('SELECT COALESCE(SUM(coins),0) n FROM users').get().n
  })), { admin: true });
  on('GET', '/api/admin/tickets', A((c) => {
    const st = ['abierto', 'respondido', 'cerrado'].includes(c.query.get('estado')) ? c.query.get('estado') : null;
    const rows = st ? q('SELECT t.*, u.name FROM tickets t JOIN users u ON u.id = t.user_id WHERE status = ? ORDER BY updated DESC LIMIT 100').all(st)
      : q('SELECT t.*, u.name FROM tickets t JOIN users u ON u.id = t.user_id ORDER BY (status = \'abierto\') DESC, updated DESC LIMIT 100').all();
    return { items: rows };
  }), { admin: true });
  on('GET', '/api/admin/tickets/:id', A((c) => {
    const t = q('SELECT t.*, u.name, u.coins, u.id AS uid FROM tickets t JOIN users u ON u.id = t.user_id WHERE t.id = ?').get(+c.params.id);
    if (!t) return [404, { error: 'No existe' }];
    q('UPDATE tickets SET unread_admin = 0 WHERE id = ?').run(t.id);
    return { ticket: t, messages: q('SELECT from_admin AS admin, text, created FROM ticket_msgs WHERE ticket_id = ? ORDER BY id').all(t.id) };
  }), { admin: true });
  on('POST', '/api/admin/tickets/:id/reply', A((c) => {
    const t = q('SELECT * FROM tickets WHERE id = ?').get(+c.params.id); if (!t) return [404, { error: 'No existe' }];
    const text = String(c.body.text || '').trim().slice(0, 4000); if (!text) return [400, { error: 'Escribe la respuesta' }];
    q('INSERT INTO ticket_msgs (ticket_id, from_admin, text, created) VALUES (?, 1, ?, ?)').run(t.id, text, now());
    q("UPDATE tickets SET status = ?, unread_user = 1, updated = ? WHERE id = ?").run(c.body.close ? 'cerrado' : 'respondido', now(), t.id);
    hub.notify(t.user_id, { t: 'notice', kind: 'ticket', id: t.id, msg: 'Soporte respondió tu consulta: ' + t.subject });
    return { ok: true };
  }), { admin: true });
  on('POST', '/api/admin/tickets/:id/close', A((c) => { q("UPDATE tickets SET status = 'cerrado', updated = ? WHERE id = ?").run(now(), +c.params.id); return { ok: true }; }), { admin: true });
  on('GET', '/api/admin/reports', A(() => ({ items: q('SELECT r.*, a.name AS reporter, b.name AS target, b.muted_until, b.banned FROM reports r LEFT JOIN users a ON a.id = r.reporter_id LEFT JOIN users b ON b.id = r.target_id WHERE resolved = 0 ORDER BY id DESC LIMIT 100').all() })), { admin: true });
  on('POST', '/api/admin/reports/:id/resolve', A((c) => { q('UPDATE reports SET resolved = 1 WHERE id = ?').run(+c.params.id); return { ok: true }; }), { admin: true });
  on('POST', '/api/admin/chat/:id/delete', A((c) => { hub.deleteChat(+c.params.id); return { ok: true }; }), { admin: true });
  on('GET', '/api/admin/chat', A(() => ({ items: q('SELECT id, user_id, name, text, created, deleted FROM chat ORDER BY id DESC LIMIT 100').all() })), { admin: true });
  on('GET', '/api/admin/users', A((c) => {
    const s = String(c.query.get('q') || '').trim().toLowerCase();
    const rows = s ? q('SELECT id, name, coins, registered, games, wins, muted_until, banned, ban_reason, created, last_seen FROM users WHERE name_lc LIKE ? OR id = ? ORDER BY last_seen DESC LIMIT 50').all('%' + s + '%', +s || -1)
      : q('SELECT id, name, coins, registered, games, wins, muted_until, banned, ban_reason, created, last_seen FROM users ORDER BY last_seen DESC LIMIT 50').all();
    return { items: rows };
  }), { admin: true });
  on('POST', '/api/admin/users/:id/coins', A((c) => {
    const id = +c.params.id, d = Math.trunc(+c.body.delta || 0); if (!d || Math.abs(d) > 1e6) return [400, { error: 'Cantidad inválida' }];
    const bal = moveCoins(id, d, 'ajuste de soporte' + (c.body.reason ? ': ' + clean(c.body.reason, 80) : ''));
    if (bal == null) return [400, { error: 'El saldo no puede quedar negativo' }];
    hub.notify(id, { t: 'coins', coins: bal, delta: d, reason: 'ajuste de soporte' });
    return { coins: bal };
  }), { admin: true });
  on('POST', '/api/admin/users/:id/mute', A((c) => {
    const min = Math.max(0, Math.min(60 * 24 * 30, +c.body.minutes || 0));
    q('UPDATE users SET muted_until = ? WHERE id = ?').run(min ? now() + min * 60e3 : 0, +c.params.id);
    hub.notify(+c.params.id, { t: 'notice', kind: 'mute', msg: min ? `No puedes escribir en el chat por ${min} minutos.` : 'Ya puedes volver a escribir en el chat.' });
    return { ok: true };
  }), { admin: true });
  on('POST', '/api/admin/users/:id/ban', A((c) => {
    const ban = !!c.body.ban, reason = clean(c.body.reason || '', 200);
    q('UPDATE users SET banned = ?, ban_reason = ? WHERE id = ?').run(ban ? 1 : 0, ban ? reason : null, +c.params.id);
    if (ban) { q('DELETE FROM sessions WHERE user_id = ?').run(+c.params.id); hub.kick(+c.params.id, reason); }
    return { ok: true };
  }), { admin: true });

  // ---- despacho ----
  const adminOk = (key) => {
    if (!CFG.ADMIN_KEY || typeof key !== 'string') return false;
    const a = createHash('sha256').update(key).digest(), b = createHash('sha256').update(CFG.ADMIN_KEY).digest();
    return timingSafeEqual(a, b);
  };
  return async function handle(req, res, url, ip, readBody, send) {
    const r = routes.find((x) => x.method === req.method && x.re.test(url.pathname));
    if (!r) return send(res, 404, { error: 'No existe' });
    const c = { ip, query: url.searchParams, params: url.pathname.match(r.re).groups || {}, body: {} };
    if (req.method === 'POST') { try { c.body = await readBody(req); } catch (e) { return send(res, 400, { error: 'Datos inválidos' }); } }
    if (r.opts.admin) {
      if (!CFG.ADMIN_KEY) return send(res, 403, { error: 'El panel está desactivado: falta configurar ADMIN_KEY en el servidor.' });
      if (!adminLimit(ip)) return send(res, 429, { error: 'Demasiadas peticiones' });
      if (!adminOk(req.headers['x-admin-key'])) return send(res, 401, { error: 'Clave incorrecta' });
    }
    if (r.opts.auth) {
      const h = req.headers.authorization || ''; c.token = h.startsWith('Bearer ') ? h.slice(7) : '';
      c.user = U.userFromToken(c.token);
      if (!c.user) return send(res, 401, { error: 'Tu sesión venció. Vuelve a entrar.' });
      if (c.user.banned) return send(res, 403, { error: 'Cuenta suspendida' });
    }
    try {
      const out = await r.fn(c);
      if (Array.isArray(out)) return send(res, out[0], out[1]);
      return send(res, 200, out);
    } catch (e) { console.error('api', url.pathname, e); return send(res, 500, { error: 'Algo salió mal. Intenta otra vez.' }); }
  };
}
