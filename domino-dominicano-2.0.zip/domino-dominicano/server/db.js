// Dominó Dominicano · base de datos (SQLite incluido en Node.js 22, sin instalar nada)
// Un solo archivo: DATA_DIR/domino.db. En producción, DATA_DIR debe estar en un disco persistente (volumen).
import { DatabaseSync } from 'node:sqlite';
import { mkdirSync } from 'node:fs';
import { join } from 'node:path';
import { CFG } from './config.js';

mkdirSync(CFG.DATA_DIR, { recursive: true });
export const db = new DatabaseSync(process.env.DB_FILE || join(CFG.DATA_DIR, 'domino.db'));
db.exec('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 3000;');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL, name_lc TEXT NOT NULL UNIQUE,
  pass TEXT, salt TEXT, registered INTEGER NOT NULL DEFAULT 0,
  coins INTEGER NOT NULL DEFAULT 0,
  avatar TEXT, prefs TEXT,
  games INTEGER NOT NULL DEFAULT 0, wins INTEGER NOT NULL DEFAULT 0, coins_won INTEGER NOT NULL DEFAULT 0,
  daily_day INTEGER NOT NULL DEFAULT 0, rescue_at INTEGER NOT NULL DEFAULT 0,
  muted_until INTEGER NOT NULL DEFAULT 0, banned INTEGER NOT NULL DEFAULT 0, ban_reason TEXT,
  created INTEGER NOT NULL, last_seen INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS sessions (
  token_hash TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created INTEGER NOT NULL, last INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS ledger (
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  delta INTEGER NOT NULL, balance INTEGER NOT NULL, reason TEXT NOT NULL, ref TEXT, created INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS ledger_user ON ledger(user_id, id);
CREATE TABLE IF NOT EXISTS chat (
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, name TEXT NOT NULL, avatar TEXT,
  text TEXT NOT NULL, created INTEGER NOT NULL, deleted INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS reports (
  id INTEGER PRIMARY KEY AUTOINCREMENT, reporter_id INTEGER NOT NULL, target_id INTEGER, msg_id INTEGER,
  text TEXT, reason TEXT, created INTEGER NOT NULL, resolved INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS tickets (
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  category TEXT NOT NULL, subject TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'abierto',
  unread_user INTEGER NOT NULL DEFAULT 0, unread_admin INTEGER NOT NULL DEFAULT 1,
  created INTEGER NOT NULL, updated INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS ticket_msgs (
  id INTEGER PRIMARY KEY AUTOINCREMENT, ticket_id INTEGER NOT NULL REFERENCES tickets(id) ON DELETE CASCADE,
  from_admin INTEGER NOT NULL DEFAULT 0, text TEXT NOT NULL, created INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS matches (
  id TEXT PRIMARY KEY, mode TEXT NOT NULL, stake INTEGER NOT NULL, status TEXT NOT NULL,
  players TEXT NOT NULL, result TEXT, created INTEGER NOT NULL, ended INTEGER
);
`);

export const q = (sql) => db.prepare(sql);
export const now = () => Date.now();

// Mueve monedas y deja constancia en el historial. Devuelve el saldo nuevo o null si no alcanza.
const updCoins = q('UPDATE users SET coins = coins + ? WHERE id = ? AND coins + ? >= 0');
const getCoins = q('SELECT coins FROM users WHERE id = ?');
const addLedger = q('INSERT INTO ledger (user_id, delta, balance, reason, ref, created) VALUES (?, ?, ?, ?, ?, ?)');
export function moveCoins(userId, delta, reason, ref = null) {
  delta = Math.trunc(delta);
  const r = updCoins.run(delta, userId, delta);
  if (!r.changes) return null;
  const bal = getCoins.get(userId).coins;
  addLedger.run(userId, delta, bal, reason, ref, now());
  return bal;
}

export function tx(fn) {
  db.exec('BEGIN');
  try { const r = fn(); db.exec('COMMIT'); return r; } catch (e) { db.exec('ROLLBACK'); throw e; }
}
