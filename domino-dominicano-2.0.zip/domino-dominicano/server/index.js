// Dominó Dominicano · servidor
// Sirve el juego (archivos del sitio), la API y las conexiones en tiempo real (/ws) desde un solo proceso.
// Uso: npm start   (variables de entorno en server/config.js y en docs/SERVIDOR.md)
import { createServer } from 'node:http';
import { readFile, stat } from 'node:fs/promises';
import { extname, join, normalize } from 'node:path';
import { CFG } from './config.js';
import { Hub } from './hub.js';
import { makeApi } from './api.js';

const TYPES = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8', '.webmanifest': 'application/manifest+json', '.svg': 'image/svg+xml',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.ico': 'image/x-icon', '.txt': 'text/plain; charset=utf-8', '.xml': 'application/xml; charset=utf-8'
};
// solo se publican estas carpetas y archivos (nunca server/, data/, tests/…)
const PUBLIC_DIRS = ['/css/', '/js/', '/shared/', '/assets/'];
const PUBLIC_FILES = new Set(['/index.html', '/reglas.html', '/privacidad.html', '/terminos.html', '/admin.html', '/404.html', '/manifest.webmanifest', '/sw.js', '/robots.txt', '/sitemap.xml', '/favicon.ico']);
const SECURITY = {
  'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'strict-origin-when-cross-origin', 'X-Frame-Options': 'SAMEORIGIN',
  'Permissions-Policy': 'camera=(), microphone=(), geolocation=()',
  'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; media-src 'self' data: blob:; connect-src 'self' ws: wss:; manifest-src 'self'; worker-src 'self'; base-uri 'self'; form-action 'self'; frame-ancestors 'self'"
};

const hub = new Hub();
const api = makeApi(hub);

const clientIp = (req) => (CFG.TRUST_PROXY && String(req.headers['x-forwarded-for'] || '').split(',')[0].trim()) || req.socket.remoteAddress || '?';
function send(res, status, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...SECURITY, ...cors(res.req) });
  res.end(body);
}
function cors(req) {
  const o = req && req.headers.origin;
  return o && CFG.ALLOWED_ORIGINS.includes(o) ? { 'Access-Control-Allow-Origin': o, 'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Admin-Key', 'Access-Control-Allow-Methods': 'GET, POST', Vary: 'Origin' } : {};
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on('data', (c) => { size += c.length; if (size > 32 * 1024) { reject(new Error('grande')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => { try { resolve(chunks.length ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : {}); } catch (e) { reject(e); } });
    req.on('error', reject);
  });
}
async function fileAt(p) { try { const s = await stat(p); return s.isFile() ? p : null; } catch { return null; } }

async function serveStatic(req, res, url) {
  let path = normalize(decodeURIComponent(url.pathname)).replace(/\\/g, '/');
  if (path.includes('..')) path = '/404';
  if (path === '/') path = '/index.html';
  if (!extname(path) && PUBLIC_FILES.has(path + '.html')) path += '.html'; // /reglas → reglas.html
  const allowed = PUBLIC_FILES.has(path) || PUBLIC_DIRS.some((d) => path.startsWith(d));
  let file = allowed ? await fileAt(join(CFG.ROOT, path)) : null, status = 200;
  if (!file) { file = join(CFG.ROOT, '404.html'); status = 404; }
  const ext = extname(file);
  const cache = ext === '.html' || path === '/sw.js' || path.startsWith('/js/') || path.startsWith('/shared/') || path.startsWith('/css/') ? 'no-cache' : 'public, max-age=604800';
  try {
    const body = await readFile(file);
    res.writeHead(status, { 'Content-Type': TYPES[ext] || 'application/octet-stream', 'Cache-Control': cache, ...SECURITY });
    res.end(req.method === 'HEAD' ? undefined : body);
  } catch { res.writeHead(404); res.end(); }
}

const server = createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  try {
    if (url.pathname.startsWith('/api/')) {
      if (req.method === 'OPTIONS') { res.writeHead(204, cors(req)); return res.end(); }
      return await api(req, res, url, clientIp(req), readBody, send);
    }
    if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405); return res.end(); }
    return await serveStatic(req, res, url);
  } catch (e) { console.error(e); if (!res.headersSent) send(res, 500, { error: 'Error del servidor' }); }
});
server.on('upgrade', (req, sock) => {
  if (new URL(req.url, 'http://x').pathname !== '/ws') return sock.destroy();
  hub.upgrade(req, sock, clientIp(req));
});
server.headersTimeout = 20000; server.requestTimeout = 30000;
server.listen(CFG.PORT, () => {
  console.log(`Dominó Dominicano → http://localhost:${CFG.PORT}`);
  if (!CFG.ADMIN_KEY) console.log('Panel de administración apagado (configura ADMIN_KEY para activarlo).');
});
const stop = () => { console.log('Cerrando…'); hub.stop(); server.close(() => process.exit(0)); setTimeout(() => process.exit(0), 3000).unref(); };
process.on('SIGTERM', stop); process.on('SIGINT', stop);
