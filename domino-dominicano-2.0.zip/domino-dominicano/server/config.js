// Dominó Dominicano · configuración del servidor
// Todo se puede cambiar con variables de entorno (en Railway/Render: pestaña "Variables").
import { fileURLToPath } from 'node:url';
import { join } from 'node:path';

const ROOT = join(fileURLToPath(new URL('.', import.meta.url)), '..');
const num = (v, d) => (v != null && v !== '' && !isNaN(+v) ? +v : d);

export const CFG = {
  ROOT,
  PORT: num(process.env.PORT, 3000),
  DATA_DIR: process.env.DATA_DIR || join(ROOT, 'data'),       // dónde se guarda la base de datos (usa un volumen en producción)
  ADMIN_KEY: process.env.ADMIN_KEY || '',                       // clave del panel de administración (/admin). Sin clave, el panel está apagado
  ALLOWED_ORIGINS: (process.env.ALLOWED_ORIGINS || '').split(',').map((s) => s.trim()).filter(Boolean), // si el sitio está en otro dominio
  TRUST_PROXY: process.env.TRUST_PROXY !== '0',                 // detrás de Railway/Render/Fly la IP real viene en X-Forwarded-For

  // monedas (ficticias: no se compran ni se cambian por dinero)
  START_COINS: num(process.env.START_COINS, 500),               // regalo de bienvenida
  DAILY_COINS: num(process.env.DAILY_COINS, 100),               // bono diario
  RESCUE_COINS: num(process.env.RESCUE_COINS, 50),              // si te quedas sin monedas…
  RESCUE_EVERY_H: num(process.env.RESCUE_EVERY_H, 6),           // …cada cuántas horas
  STAKES: [10, 20, 40, 80],                                     // montos de las mesas
  TZ_OFFSET_H: num(process.env.TZ_OFFSET_H, -4),                // día del bono diario (hora de República Dominicana)

  // mesas
  QUEUE_WAIT_MS: num(process.env.QUEUE_WAIT_MS, 12000),         // si no aparecen personas en este tiempo, se completa con la computadora
  GUEST_PER_HOUR: num(process.env.GUEST_PER_HOUR, 30),           // cuentas de invitado nuevas por hora desde una misma conexión
  TIME_SCALE: num(process.env.TIME_SCALE, 1),                   // solo para pruebas: acelera los tiempos de la mesa

  // chat
  CHAT_MAX: 200, CHAT_HISTORY: 60, CHAT_RATE: [5, 10000],       // máx. 5 mensajes cada 10 s
};
