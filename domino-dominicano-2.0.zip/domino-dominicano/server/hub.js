// Dominó Dominicano · centro del juego en línea
// Conexiones en tiempo real, quién está en línea, chat del lobby y de la mesa, búsqueda de mesa, mesas en juego,
// cobro de la apuesta al empezar y pago del premio al terminar.
import { createRequire } from 'node:module';
import { randomBytes } from 'node:crypto';
import { accept, heartbeat } from './ws.js';
import { q, now, tx, moveCoins } from './db.js';
import { CFG } from './config.js';
import { clean, limiter } from './moderation.js';
import { userFromToken, getUser, publicMe, P } from './users.js';

const require = createRequire(import.meta.url);
const E = require('../shared/engine.js');
const Room = require('../shared/room.js');

const BOT_NAMES = ['Ramón', 'Mayra', 'Felo', 'Yohanna', 'Nelson', 'Chichí', 'Wandy', 'Dulce', 'Papo', 'Luisa', 'Kelvin', 'Yuly', 'Tony', 'Nena', 'Fello', 'Mingo', 'Cuca', 'Bienve'];

const insChat = q('INSERT INTO chat (user_id, name, avatar, text, created) VALUES (?, ?, ?, ?, ?)');
const lastChat = q('SELECT id, user_id AS uid, name, avatar, text, created AS ts FROM chat WHERE deleted = 0 ORDER BY id DESC LIMIT ?');
const insMatch = q('INSERT INTO matches (id, mode, stake, status, players, created) VALUES (?, ?, ?, ?, ?, ?)');
const endMatch = q('UPDATE matches SET status = ?, result = ?, ended = ? WHERE id = ?');
const statUser = q('UPDATE users SET games = games + 1, wins = wins + ?, coins_won = coins_won + ? WHERE id = ?');

export class Hub {
  constructor() {
    this.socks = new Set();           // conexiones abiertas
    this.byUser = new Map();          // id de usuario → conexiones
    this.queues = new Map();          // 'modo|monto' → [{ uid, since }]
    this.rooms = new Map();           // id de mesa → { room, mode, stake, seats:[uid|null] }
    this.userRoom = new Map();        // id de usuario → { id, seat }
    this.chatOk = limiter(CFG.CHAT_RATE[0], CFG.CHAT_RATE[1]);
    this.tableOk = limiter(6, 10000);
    this.reportOk = limiter(5, 600000);
    this.presenceDirty = true;
    this.voidActive();
    this.timers = [setInterval(() => this.tick(), 1000), heartbeat(this.socks)];
  }

  // ---- conexiones ----
  upgrade(req, sock, ip) {
    const origin = req.headers.origin;
    if (origin && !this.originOk(origin, req.headers.host)) { sock.end('HTTP/1.1 403 Forbidden\r\n\r\n'); return; }
    const ws = accept(req, sock); if (!ws) return;
    const conn = { ws, user: null, ip, at: now() };
    this.socks.add(ws);
    ws.on('message', (m) => { try { this.onMsg(conn, m); } catch (e) { console.error('ws', e); } });
    ws.on('close', () => this.onClose(conn));
    conn.authTimer = setTimeout(() => { if (!conn.user) ws.close(4001); }, 10000);
  }
  originOk(origin, host) {
    try { const o = new URL(origin); if (o.host === host) return true; } catch { return false; }
    return CFG.ALLOWED_ORIGINS.includes(origin);
  }
  send(conn, msg) { conn.ws.send(msg); }
  sendUser(uid, msg) { const set = this.byUser.get(uid); if (!set) return; const s = JSON.stringify(msg); for (const c of set) c.ws.send(s); }
  broadcast(msg) { const s = JSON.stringify(msg); for (const set of this.byUser.values()) for (const c of set) c.ws.send(s); }
  online(uid) { return this.byUser.has(uid); }

  onClose(conn) {
    this.socks.delete(conn.ws); clearTimeout(conn.authTimer);
    if (!conn.user) return;
    const uid = conn.user.id, set = this.byUser.get(uid);
    if (set) { set.delete(conn); if (!set.size) { this.byUser.delete(uid); this.unqueue(uid); this.presenceDirty = true;
      const ur = this.userRoom.get(uid); if (ur) { const R = this.rooms.get(ur.id); if (R) R.room.setConnected(ur.seat, false); } } }
  }

  onMsg(conn, raw) {
    let m; try { m = JSON.parse(raw); } catch { return; }
    if (!m || typeof m.t !== 'string') return;
    if (!conn.user) { if (m.t === 'hello') this.hello(conn, m); return; }
    const user = getUser(conn.user.id);
    if (!user || user.banned) { conn.ws.close(4003); return; }
    conn.user = user;
    switch (m.t) {
      case 'chat': return this.chat(conn, user, m);
      case 'report': return this.report(conn, user, m);
      case 'queue': return this.queue(conn, user, m);
      case 'unqueue': this.unqueue(user.id); return this.send(conn, { t: 'unqueued' });
      case 'act': return this.act(conn, user, m);
      case 'leave': return this.leave(conn, user);
      case 'resume': return this.resume(conn, user);
      case 'me': return this.send(conn, { t: 'me', me: publicMe(user) });
      case 'ping': return this.send(conn, { t: 'pong' });
    }
  }

  hello(conn, m) {
    const user = userFromToken(m.token);
    if (!user) { this.send(conn, { t: 'auth', ok: false }); conn.ws.close(4001); return; }
    if (user.banned) { this.send(conn, { t: 'banned', reason: user.ban_reason || '' }); conn.ws.close(4003); return; }
    clearTimeout(conn.authTimer);
    conn.user = user;
    if (!this.byUser.has(user.id)) { this.byUser.set(user.id, new Set()); this.presenceDirty = true; }
    this.byUser.get(user.id).add(conn);
    const chat = lastChat.all(CFG.CHAT_HISTORY).reverse();
    this.send(conn, { t: 'welcome', me: publicMe(user), chat, stakes: CFG.STAKES, modes: Object.values(E.MODES).map((x) => ({ key: x.key, label: x.label, n: x.n, target: x.target })), presence: this.presence(), queue: this.queueOf(user.id) });
    this.resume(conn, user);
  }
  resume(conn, user) {
    const ur = this.userRoom.get(user.id); if (!ur) return;
    const R = this.rooms.get(ur.id); if (!R) { this.userRoom.delete(user.id); return; }
    R.room.setConnected(ur.seat, true);
    this.send(conn, { t: 'matched', resume: true, view: R.room.view(ur.seat) });
  }

  // ---- chat ----
  chat(conn, user, m) {
    if (user.muted_until > now()) return this.send(conn, { t: 'error', msg: 'No puedes escribir en el chat por ahora.' });
    const text = clean(m.text, CFG.CHAT_MAX);
    if (!text) return;
    if (m.scope === 'mesa') {
      const ur = this.userRoom.get(user.id); if (!ur) return;
      if (!this.tableOk(user.id)) return this.send(conn, { t: 'error', msg: 'Más despacio con los mensajes.' });
      const R = this.rooms.get(ur.id); if (!R) return;
      const msg = { t: 'tchat', seat: ur.seat, name: user.name, text, ts: now() };
      for (const uid of R.seats) if (uid) this.sendUser(uid, msg);
      return;
    }
    if (!this.chatOk(user.id)) return this.send(conn, { t: 'error', msg: 'Estás escribiendo muy rápido. Espera unos segundos.' });
    const ts = now(), r = insChat.run(user.id, user.name, user.avatar, text, ts);
    this.broadcast({ t: 'chat', m: { id: Number(r.lastInsertRowid), uid: user.id, name: user.name, avatar: user.avatar, text, ts } });
    if (Number(r.lastInsertRowid) % 200 === 0) q('DELETE FROM chat WHERE id < ?').run(Number(r.lastInsertRowid) - 5000);
  }
  report(conn, user, m) {
    if (!this.reportOk(user.id)) return this.send(conn, { t: 'error', msg: 'Ya enviaste varios reportes. Gracias, los revisaremos.' });
    const msg = q('SELECT * FROM chat WHERE id = ?').get(m.id | 0);
    if (!msg) return;
    q('INSERT INTO reports (reporter_id, target_id, msg_id, text, reason, created) VALUES (?, ?, ?, ?, ?, ?)').run(user.id, msg.user_id, msg.id, msg.text, clean(m.reason || '', 200), now());
    this.send(conn, { t: 'notice', kind: 'report', msg: 'Gracias. Nuestro equipo revisará ese mensaje.' });
  }
  deleteChat(id) { q('UPDATE chat SET deleted = 1 WHERE id = ?').run(id); this.broadcast({ t: 'chatdel', id }); }

  // ---- buscar mesa ----
  queueOf(uid) { for (const [k, list] of this.queues) if (list.some((x) => x.uid === uid)) { const [mode, stake] = k.split('|'); return { mode, stake: +stake }; } return null; }
  queue(conn, user, m) {
    const mode = E.MODES[m.mode] ? m.mode : null, stake = CFG.STAKES.includes(+m.stake) ? +m.stake : null;
    if (!mode || !stake) return this.send(conn, { t: 'error', msg: 'Elige un modo y un monto.' });
    if (this.userRoom.has(user.id)) return this.resume(conn, user);
    if (user.coins < stake) return this.send(conn, { t: 'error', msg: 'No te alcanzan las monedas para esa mesa.', code: 'coins' });
    this.unqueue(user.id);
    const key = mode + '|' + stake;
    if (!this.queues.has(key)) this.queues.set(key, []);
    this.queues.get(key).push({ uid: user.id, since: now() });
    this.sendUser(user.id, { t: 'queued', mode, stake, wait: CFG.QUEUE_WAIT_MS });
    this.presenceDirty = true;
    this.tick();
  }
  unqueue(uid) {
    for (const [k, list] of this.queues) { const i = list.findIndex((x) => x.uid === uid); if (i >= 0) { list.splice(i, 1); this.presenceDirty = true; if (!list.length) this.queues.delete(k); } }
  }
  tick() {
    for (const [key, list] of this.queues) {
      const [mode, stakeS] = key.split('|'), stake = +stakeS, n = E.MODES[mode].n;
      // fuera los que ya no están conectados
      for (let i = list.length - 1; i >= 0; i--) if (!this.online(list[i].uid)) list.splice(i, 1);
      while (list.length >= n) this.createRoom(mode, stake, list.splice(0, n).map((x) => x.uid));
      if (list.length && now() - list[0].since >= CFG.QUEUE_WAIT_MS) this.createRoom(mode, stake, list.splice(0, list.length).map((x) => x.uid));
      if (!list.length) this.queues.delete(key);
    }
    if (this.presenceDirty) { this.presenceDirty = false; this.broadcast({ t: 'presence', ...this.presence() }); }
  }
  presence() {
    const queues = {}; for (const [k, l] of this.queues) queues[k] = l.length;
    let playing = 0; for (const R of this.rooms.values()) playing += R.seats.filter(Boolean).length;
    return { online: this.byUser.size, playing, queues };
  }

  // ---- mesas ----
  createRoom(mode, stake, uids) {
    const n = E.MODES[mode].n, id = randomBytes(6).toString('hex');
    // cobrar la apuesta (si a alguien ya no le alcanza, se queda fuera)
    const humans = [];
    tx(() => { for (const uid of uids) { if (moveCoins(uid, -stake, 'apuesta', id) != null) humans.push(uid); else this.sendUser(uid, { t: 'error', msg: 'No te alcanzan las monedas para esa mesa.', code: 'coins' }); } });
    if (!humans.length) return;
    const seats = Array(n).fill(null), free = [...Array(n).keys()];
    for (const uid of humans) { const k = Math.floor(Math.random() * free.length); seats[free.splice(k, 1)[0]] = uid; }
    const names = BOT_NAMES.slice().sort(() => Math.random() - .5);
    const players = seats.map((uid, i) => {
      if (uid) { const u = getUser(uid); return { uid, name: u.name, avatar: u.avatar, bot: false }; }
      return { name: names[i], avatar: P.random(), bot: true };
    });
    insMatch.run(id, mode, stake, 'activa', JSON.stringify(players.map((p) => ({ uid: p.uid || null, name: p.name, bot: p.bot }))), now());
    const R = { mode, stake, seats, created: now() };
    R.room = new Room({
      id, mode, stake, players,
      send: (seat, msg) => { const uid = seats[seat]; if (uid && this.userRoom.get(uid)?.id === id) this.sendUser(uid, msg); },
      onEnd: (info) => this.settle(id, info),
      onLog: (k, e) => console.error('room', k, e),
      timing: CFG.TIME_SCALE !== 1 ? Object.fromEntries(Object.entries(Room.TIMING).map(([k, v]) => [k, Array.isArray(v) ? v.map((x) => x * CFG.TIME_SCALE) : v * CFG.TIME_SCALE])) : undefined
    });
    this.rooms.set(id, R);
    seats.forEach((uid, seat) => { if (uid) { this.userRoom.set(uid, { id, seat }); this.unqueue(uid); } });
    for (const uid of humans) {
      this.sendUser(uid, { t: 'coins', coins: getUser(uid).coins, delta: -stake, reason: 'apuesta' });
      if (!this.online(uid)) R.room.setConnected(seats.indexOf(uid), false);
    }
    R.room.start();
    seats.forEach((uid, seat) => { if (uid) this.sendUser(uid, { t: 'matched', view: R.room.view(seat) }); });
    this.presenceDirty = true;
  }

  act(conn, user, m) {
    const ur = this.userRoom.get(user.id); if (!ur) return this.send(conn, { t: 'error', msg: 'No estás en una mesa.' });
    const R = this.rooms.get(ur.id); if (!R) return;
    const err = R.room.action(ur.seat, m.a);
    if (err) this.send(conn, { t: 'reject', msg: err, a: m.a });
  }
  leave(conn, user) {
    const ur = this.userRoom.get(user.id); if (!ur) return this.send(conn, { t: 'left' });
    const R = this.rooms.get(ur.id);
    if (R && !R.room.ended) R.room.leave(ur.seat);
    this.userRoom.delete(user.id);
    this.sendUser(user.id, { t: 'left' });
    this.presenceDirty = true;
  }

  // ---- fin de la partida: premios ----
  settle(id, info) {
    const R = this.rooms.get(id); if (!R) return;
    const prize = R.stake * 2, results = [];
    tx(() => {
      info.players.forEach((p) => {
        const uid = R.seats[p.seat]; if (!uid) return;
        const won = p.team === info.winnerTeam;
        const stillHere = this.userRoom.get(uid)?.id === id;
        let coins = null;
        if (won && stillHere) coins = moveCoins(uid, prize, 'premio', id);
        statUser.run(won && stillHere ? 1 : 0, won && stillHere ? R.stake : 0, uid);
        results.push({ uid, seat: p.seat, won: won && stillHere, coins });
      });
      endMatch.run('terminada', JSON.stringify({ scores: info.scores, winnerTeam: info.winnerTeam, results }), now(), id);
    });
    for (const r of results) {
      if (this.userRoom.get(r.uid)?.id === id) {
        const u = getUser(r.uid);
        this.sendUser(r.uid, { t: 'coins', coins: u.coins, delta: r.won ? prize : 0, reason: r.won ? 'premio' : 'partida perdida' });
        this.sendUser(r.uid, { t: 'me', me: publicMe(u) });
        this.userRoom.delete(r.uid);
      }
    }
    setTimeout(() => { R.room.destroy(); this.rooms.delete(id); this.presenceDirty = true; }, 5000);
  }

  // si el servidor se reinició con partidas a medias, se devuelven las apuestas
  voidActive() {
    const rows = q("SELECT * FROM matches WHERE status = 'activa'").all();
    for (const m of rows) tx(() => {
      for (const p of JSON.parse(m.players)) if (p.uid) moveCoins(p.uid, m.stake, 'devolución (partida interrumpida)', m.id);
      endMatch.run('anulada', null, now(), m.id);
    });
    if (rows.length) console.log(`Devueltas las apuestas de ${rows.length} partida(s) interrumpida(s).`);
  }

  notify(uid, msg) { this.sendUser(uid, msg); }
  kick(uid, reason) { const set = this.byUser.get(uid); if (set) for (const c of set) { c.ws.send(JSON.stringify({ t: 'banned', reason })); c.ws.close(4003); } }
  stats() { return { ...this.presence(), rooms: this.rooms.size, sockets: this.socks.size }; }
  stop() { this.timers.forEach(clearInterval); for (const R of this.rooms.values()) R.room.destroy(); }
}
