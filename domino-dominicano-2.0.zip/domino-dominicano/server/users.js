// Dominó Dominicano · cuentas, sesiones y monedas
import { randomBytes, scryptSync, timingSafeEqual, createHash } from 'node:crypto';
import { createRequire } from 'node:module';
import { db, q, now, moveCoins, tx } from './db.js';
import { CFG } from './config.js';
import { hasBad } from './moderation.js';

const require = createRequire(import.meta.url);
export const P = require('../shared/profile.js');

const sha = (s) => createHash('sha256').update(s).digest('hex');
const hashPass = (pw, salt) => scryptSync(pw, salt, 32, { N: 16384, r: 8, p: 1 }).toString('hex');

const sel = q('SELECT * FROM users WHERE id = ?');
const selName = q('SELECT * FROM users WHERE name_lc = ?');
const ins = q('INSERT INTO users (name, name_lc, coins, avatar, prefs, created, last_seen) VALUES (?, ?, 0, ?, ?, ?, ?)');
const insSess = q('INSERT INTO sessions (token_hash, user_id, created, last) VALUES (?, ?, ?, ?)');
const selSess = q('SELECT user_id FROM sessions WHERE token_hash = ?');
const touch = q('UPDATE sessions SET last = ? WHERE token_hash = ?');
const delSess = q('DELETE FROM sessions WHERE token_hash = ?');
const seen = q('UPDATE users SET last_seen = ? WHERE id = ?');

export const getUser = (id) => sel.get(id);
export const userByName = (name) => selName.get(String(name || '').trim().toLowerCase());

// Lo que el jugador ve de su propia cuenta
export function publicMe(u) {
  return {
    id: u.id, name: u.name, avatar: u.avatar, coins: u.coins, registered: !!u.registered,
    prefs: P.cleanPrefs(safeJson(u.prefs)), games: u.games, wins: u.wins, coinsWon: u.coins_won,
    daily: dailyAvailable(u), rescue: rescueAvailable(u), muted: u.muted_until > now() ? u.muted_until : 0
  };
}
export const publicUser = (u) => ({ id: u.id, name: u.name, avatar: u.avatar });
function safeJson(s) { try { return JSON.parse(s || '{}'); } catch { return {}; } }

export function newSession(userId) {
  const token = randomBytes(32).toString('hex');
  insSess.run(sha(token), userId, now(), now());
  return token;
}
export function userFromToken(token) {
  if (typeof token !== 'string' || token.length !== 64) return null;
  const h = sha(token), s = selSess.get(h);
  if (!s) return null;
  touch.run(now(), h); seen.run(now(), s.user_id);
  return sel.get(s.user_id);
}
export const endSession = (token) => { if (typeof token === 'string') delSess.run(sha(token)); };

// Cuenta de invitado: entra al momento, con monedas de bienvenida. Luego puede ponerle contraseña.
export function createGuest() {
  return tx(() => {
    let name, tries = 0;
    do { name = 'Jugador' + (1000 + Math.floor(Math.random() * 9000)); } while (selName.get(name.toLowerCase()) && ++tries < 50);
    if (tries >= 50) name = 'Jugador' + Date.now().toString(36);
    const r = ins.run(name, name.toLowerCase(), P.random(), JSON.stringify(P.DEFAULT_PREFS), now(), now());
    const id = Number(r.lastInsertRowid);
    moveCoins(id, CFG.START_COINS, 'bienvenida');
    return sel.get(id);
  });
}

export function nameError(name, selfId) {
  const e = P.checkName(name); if (e) return e;
  const n = name.trim().replace(/\s+/g, ' ');
  if (hasBad(n)) return 'Ese nombre no está permitido';
  const other = selName.get(n.toLowerCase());
  if (other && other.id !== selfId) return 'Ese nombre ya lo tiene otra persona';
  return null;
}

export function register(user, name, password) {
  const e = nameError(name, user.id); if (e) return { error: e };
  if (typeof password !== 'string' || password.length < 6) return { error: 'La contraseña debe tener al menos 6 caracteres' };
  if (password.length > 100) return { error: 'La contraseña es demasiado larga' };
  const n = name.trim().replace(/\s+/g, ' '), salt = randomBytes(16).toString('hex');
  q('UPDATE users SET name = ?, name_lc = ?, pass = ?, salt = ?, registered = 1 WHERE id = ?').run(n, n.toLowerCase(), hashPass(password, salt), salt, user.id);
  return { user: sel.get(user.id) };
}

export function login(name, password) {
  const u = userByName(name);
  if (!u || !u.pass || typeof password !== 'string') return { error: 'Nombre o contraseña incorrectos' };
  const a = Buffer.from(hashPass(password, u.salt), 'hex'), b = Buffer.from(u.pass, 'hex');
  if (a.length !== b.length || !timingSafeEqual(a, b)) return { error: 'Nombre o contraseña incorrectos' };
  if (u.banned) return { error: 'Esta cuenta está suspendida' + (u.ban_reason ? ': ' + u.ban_reason : '') };
  return { user: u, token: newSession(u.id) };
}

export function updateProfile(user, body) {
  const out = {};
  if (body.name != null && body.name !== user.name) {
    const e = nameError(body.name, user.id); if (e) return { error: e };
    out.name = body.name.trim().replace(/\s+/g, ' ');
  }
  if (body.avatar != null) { if (!P.valid(body.avatar)) return { error: 'Avatar inválido' }; out.avatar = body.avatar; }
  if (body.prefs != null) out.prefs = JSON.stringify(P.cleanPrefs(body.prefs));
  if (out.name) q('UPDATE users SET name = ?, name_lc = ? WHERE id = ?').run(out.name, out.name.toLowerCase(), user.id);
  if (out.avatar) q('UPDATE users SET avatar = ? WHERE id = ?').run(out.avatar, user.id);
  if (out.prefs) q('UPDATE users SET prefs = ? WHERE id = ?').run(out.prefs, user.id);
  return { user: sel.get(user.id) };
}

// ---- bonos ----
const dayNum = (t = now()) => Math.floor((t + CFG.TZ_OFFSET_H * 3600e3) / 86400e3);
export const dailyAvailable = (u) => u.daily_day < dayNum();
export const rescueAvailable = (u) => u.coins < Math.min(...CFG.STAKES) && now() - u.rescue_at >= CFG.RESCUE_EVERY_H * 3600e3;
export function claimDaily(u) {
  if (!dailyAvailable(u)) return { error: 'Ya cobraste el bono de hoy. Vuelve mañana.' };
  return tx(() => { q('UPDATE users SET daily_day = ? WHERE id = ?').run(dayNum(), u.id); const coins = moveCoins(u.id, CFG.DAILY_COINS, 'bono diario'); return { coins, amount: CFG.DAILY_COINS }; });
}
export function claimRescue(u) {
  if (!rescueAvailable(u)) return { error: 'El bono de rescate es para cuando te quedas sin monedas, una vez cada ' + CFG.RESCUE_EVERY_H + ' horas.' };
  return tx(() => { q('UPDATE users SET rescue_at = ? WHERE id = ?').run(now(), u.id); const coins = moveCoins(u.id, CFG.RESCUE_COINS, 'bono de rescate'); return { coins, amount: CFG.RESCUE_COINS }; });
}

export function leaderboard() {
  return q('SELECT id, name, avatar, coins, wins, games FROM users WHERE banned = 0 AND (games > 0 OR registered = 1) ORDER BY coins DESC, wins DESC LIMIT 25').all();
}
export function history(u) {
  return q('SELECT delta, balance, reason, created FROM ledger WHERE user_id = ? ORDER BY id DESC LIMIT 40').all(u.id);
}
export { db, moveCoins };
