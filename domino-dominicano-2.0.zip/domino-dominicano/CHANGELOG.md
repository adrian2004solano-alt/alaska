# Historial de cambios

## 2.0.0 — 12 de octubre de 2026

- **Lobby** antes de jugar: perfil con avatar, saldo de monedas, bono diario y de rescate, modos Parejas y 1 vs 1,
  montos 10/20/40/80, chat en vivo, personalización, ranking, soporte y perfil.
- **Juego en línea** con servidor propio: cuentas (invitado o con contraseña), emparejamiento, mesas completadas con
  la computadora (marcada BOT), reconexión, abandono, chat de mesa con frases rápidas.
- **Monedas ficticias**: 500 de bienvenida, 100 diarias; al empezar se aparta el monto y el ganador recibe el doble.
- **1 vs 1** con pozo (robar hasta que salga una ficha que sirva), a 100 puntos. Parejas a 200.
- **Servicio al cliente**: preguntas frecuentes, consultas con respuesta dentro del juego y panel `/admin`.
- **Moderación**: groserías tapadas, enlaces bloqueados, límite de mensajes, reportes, silenciar y suspender.
- **Personalización**: avatar (piel, pelo, sombrero, lentes, barba, fondo), paño (bandera, verde, azul, vino), madera
  (nogal, caoba, roble, ébano), fichas (marfil, perla, negras) y puntos de colores.
- Motor de reglas único para servidor y práctica; pruebas con 3.000 partidas simuladas y varios jugadores conectados.

## 1.0.0 — 12 de octubre de 2026

Primera versión pública como proyecto completo.

**Proyecto**
- El juego pasa de un solo archivo HTML a un proyecto organizado: `css/`, `js/` (app, core, game, render), `assets/`.
- Pantalla de carga, botón "Cómo jugar", preferencia de sonido guardada.
- App instalable (manifiesto e iconos) y modo sin conexión.
- SEO e imagen para compartir en redes; página de reglas, privacidad y 404.
- Configuración de Vercel con encabezados de seguridad y caché.
- Pruebas automáticas (35 comprobaciones) y pruebas en GitHub Actions.

**Juego** (lo desarrollado en las versiones de prueba v4–v11)
- Reglas dominicanas: sale el 6|6, pase (25), pase corrido (30, automático), capicúa (puntas distintas), tranque.
- Dobles siempre atravesados y centrados; la ficha siguiente sale del medio del doble; sin choques ni fichas fuera de la mesa.
- Mesa con la bandera dominicana, madera realista, portavasos de acero, vaso de ron.
- Atriles 3D con las fichas recostadas; textura de marfil en las fichas.
- Fin de mano: quien gana le da duro a la mesa, las fichas se desordenan, se voltean y se barajan para la siguiente mano.
- Reparto tocando las fichas de la mesa; ordenar la mano arrastrando; funciona en vertical y horizontal.
